#!/usr/bin/env python

from __future__ import print_function
import wx
import wx.grid
import os
import cProfile
import InstrumentationModel
import InstrumentationBrowserVersion
import weakref
import sys
import getopt
import errno
import json
import re
import stat
import wx.lib.newevent
import random
import types
# import matplotlib
# matplotlib.use('WXAgg')
# import numpy
# from numpy import arange, sin, pi
# from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
# from matplotlib.backends.backend_wx import NavigationToolbar2Wx
# from matplotlib.figure import Figure
import tarfile
import unicodedata
import shutil
import collections
from os.path import expanduser
import wx.lib.scrolledpanel
import wx.lib.inspection
import re
import time
import threading

def warning(*objs):
    print(sys.argv[0] + ":", *objs, file=sys.stderr)

def GetClassAndFunction(fullname):
    fullname = fullname.replace("(anonymous namespace)::", "")
    func_end = fullname.rfind('(')
    if func_end == -1:
        func_end = len(fullname)
    scan = func_end - 1
    c = None
    while scan >= 0:
        c = fullname[scan]
        if c != ' ' and c != '*' and c != ':':
            scan = scan - 1
        else:
            break
    funcname = fullname[scan+1:func_end]
    classname = ''
    if c == ':':
        scan = scan - 1
        c = fullname[scan]
        if c == ':':
            class_end = scan
            scan = scan - 1
            while scan >= 0:
                c = fullname[scan]
                if c != ' ' and c != '*' and c != ':':
                    scan = scan - 1
                else:
                    break
            classname = fullname[scan+1:class_end]
    return classname,funcname

class SettingsDialog(wx.Dialog): 
    def __init__(self, parent, settings): 
        wx.Dialog.__init__(self, parent, -1, "Settings",
                           style=wx.DEFAULT_DIALOG_STYLE | \
                           wx.RESIZE_BORDER | wx.THICK_FRAME)
        self.source_path = wx.TextCtrl(self, value=settings["SourceDir"], size=(500, -1))
        self.source_path.SetToolTipString("Source path directory") 
        self.editor_command = wx.TextCtrl(self, wx.ID_ANY,
                                          settings["EditorCmd"]) 
        self.editor_command.SetToolTipString("Command to use for editor ($n is line number, $f is absolute filename)")
        self.search_mode_plain_text = wx.CheckBox(self, wx.ID_ANY, label="Search expr as plain text",
                                       style=wx.ALIGN_RIGHT)
        self.search_mode_plain_text.SetToolTipString("Set if Search Expr is treated as plain text rather than regular expression")
        self.search_mode_plain_text.SetValue(settings["SearchModePlainText"])
        self.gridsizer = wx.FlexGridSizer(0,2,10,10) 
        self.gridsizer.AddMany([ 
            wx.StaticText(self, -1, "Source Path:"), 
            (self.source_path, 0, wx.EXPAND), 
            wx.StaticText(self, -1, "Editor Command:"), 
            (self.editor_command, 0, wx.EXPAND),
            self.search_mode_plain_text])
        self.gridsizer.AddGrowableCol(1, 1)
        self.ButtonSizer = wx.BoxSizer(wx.HORIZONTAL) 
        self.ButtonSizer.AddMany([ 
            (wx.Button(self, wx.ID_OK), 0, wx.ALL, 5), 
            (wx.Button(self, wx.ID_CANCEL), 0, wx.ALL, 5), 
            ]) 
        self.sizer = wx.BoxSizer(wx.VERTICAL) 
        self.sizer.AddMany([ 
            (self.gridsizer, 1, wx.EXPAND | wx.ALL, 10,), 
            (self.ButtonSizer, 0, wx.ALIGN_CENTER), 
            ]) 
        self.SetSizer(self.sizer)
        self.Fit()

    def GetSourceDir(self):
        return self.source_path.GetValue()

    def GetEditorCmd(self):
        return self.editor_command.GetValue()

    def GetSearchModePlainText(self):
        return self.search_mode_plain_text.IsChecked()

class ContextMenu(object):
    def __init__(self):
        super(ContextMenu, self).__init__()
        self._menu = None
        self.Bind(wx.EVT_CONTEXT_MENU, self.OnContextMenu)
        self.Bind(wx.grid.EVT_GRID_CELL_RIGHT_CLICK, self.OnContextMenu)

    def OnContextMenu(self, event):
        if self._menu is not None:
            self._menu.Destroy()
        self._menu = wx.Menu()
        self.CreateContextMenu(self._menu, event)
        self.PopupMenu(self._menu)

    def CreateContextMenu(self, menu, event):
        raise NotImplementedError

INST_POINT_TABLE_THREAD_COL=0
INST_POINT_TABLE_TIME_COL=1
INST_POINT_TABLE_FUNC_COL=2
INST_POINT_TABLE_SESSION_ID_COL=3
INST_POINT_TABLE_DESC_COL=4


def RepresentsInt(s):
    try:
        int(s)
        return True
    except ValueError:
        return False

replacements={}
def replace(match):
    return replacements[match.group(0)]

class InstPointTable(wx.grid.PyGridTableBase):
    def __init__(self, data, datapoints, context_button, filtered_points, mode, background, low, high, static,
                    rowLabels=None, colLabels=None):
        wx.grid.PyGridTableBase.__init__(self)
        self.data = data
        self.datapoints = datapoints
        self.context_button = context_button
        self.filtered = filtered_points
        self.rowLabels = rowLabels
        self.colLabels = colLabels
        self.highlight_range = None
        self.highlight_row_set = set()
        self.mode=mode
        self.background_color = background
        self.low = low
        self.high = high
        self.static = static

    def GetStringFromRow(self, row):
        data_str = str(self.GetRowLabelValue(row)) + " "
        data_str = data_str.ljust(9)
        data_str += self.GetValue(row, INST_POINT_TABLE_THREAD_COL) + " "
        data_str = data_str.ljust(9 + 7)
        data_str += str(self.GetValue(row, INST_POINT_TABLE_TIME_COL)) + " "
        data_str = data_str.ljust(9 + 7 + 12)
        data_str += self.GetValue(row, INST_POINT_TABLE_FUNC_COL) + ": "
        data_str += self.GetValue(row, INST_POINT_TABLE_DESC_COL)
        return data_str
    
    def GetNumberRows(self):
        return len(self.data)

    def GetNumberCols(self):
        return len(self.colLabels)

    def GetColLabelValue(self, col):
        if self.colLabels:
            return self.colLabels[col]
        
    def GetRowLabelValue(self, row):
        return self.data[row].GetSampleNumber()
        
    def IsEmptyCell(self, row, col):
        return False

    def GetRowA0(self, row):
        if self.data[row].HasSessionID():
            return self.data[row].GetSessionID()
        else:
            return None

    def GetRowA1(self, row):
        if self.data[row].HasSocketID():
            return self.data[row].GetSocketID()
        else:
            return None

    def GetRowArguments(self, row):
        return self.data[row].GetArguments()
        
    def GetRowDataId(self, row):
        return self.data[row].GetPointID()

    def GetRowThreadId(self, row):
        return self.data[row].GetThread()

    def GetValue(self, row, col):
        if col == INST_POINT_TABLE_THREAD_COL:
            return hex(self.data[row].GetThread())
        if col == INST_POINT_TABLE_TIME_COL:
            return float(self.data[row].GetAdjustedClock()) / 1000000
        if col == INST_POINT_TABLE_FUNC_COL:
            classname,funcname = \
              GetClassAndFunction(self.data[row].GetFunction())
            return classname + '::' + funcname
        if col == INST_POINT_TABLE_SESSION_ID_COL:
            session_str = ''
            if self.data[row].HasSessionID():
                session_str = str(self.data[row].GetSessionID())+' '
            if session_str:
                return session_str
            else :
                return str(-1)
        if col == INST_POINT_TABLE_DESC_COL:
            desc_str = ''
            if self.data[row].HasSocketID():
                desc_str += 'a1='+str(self.data[row].GetSocketID())+' '
            args_list=self.data[row].GetArguments()
            if self.mode == "HEX":
                args_list_hex = []
                global replacements
                replacements={}
                desc = self.data[row].GetDescription()
                for arg in args_list:
                    if RepresentsInt(str(arg)):
                        args_list_hex.append(hex(arg))
                    else:
                        arg.remove(args_list)
                for arg,arg_hex in zip(args_list,args_list_hex):
                    replacements[str(arg)]=arg_hex
                if replacements:
                    desc=re.sub('|'.join(r'\b%s\b' % re.escape(s) for s in replacements),replace, desc)
                desc_str+=desc
            elif self.mode == "DEC":
                desc_str += self.data[row].GetDescription()
            return desc_str
            
    def SetValue(self, row, col, value):
        pass

    def GetSessionIdForRow(self, row):
        if self.data[row].HasSessionID():
            return self.data[row].GetSessionID()
        return None

    def GetSocketIdForRow(self, row):
        if self.data[row].HasSocketID():
            return self.data[row].GetSocketID()
        return None

    def GetDescriptionForRow(self, row):
        return self.data[row].GetDescription()

    def GetTypeForRow(self, row):
        return self.data[row].GetType()

    def GetColourForRow(self, row):
        if self.context_button == True and self.data[row] not in self.filtered and \
            len(self.data) != len(self.datapoints):
            return 'GRAY'
        row_data_type = self.data[row].GetType()
        if row_data_type == \
          InstrumentationModel.PointDefinition.type_low:
            return eval(self.low)
        elif row_data_type == \
          InstrumentationModel.PointDefinition.type_static:
            return eval(self.static)
        else:
            return eval(self.high)

    def GetBackgroundColour(self):
        return eval(self.background_color)

    def GetAttr(self, row, col, extra_params):
        colour = self.GetColourForRow(row)
        background = self.GetBackgroundColour()
        attr = wx.grid.GridCellAttr()
        attr.SetTextColour(colour)
        attr.SetBackgroundColour(background)
        if (self.highlight_range and \
          row >= self.highlight_range[0] and \
          row <= self.highlight_range[1]):
                attr.SetBackgroundColour("YELLOW")
        else:
          if row in self.highlight_row_set:
              attr.SetBackgroundColour("LIGHT BLUE")
        return attr

    def SetRowHighlightSet(self, row_list):
        self.highlight_row_set = row_list

    def SetRangeColour(self, color_range):
        self.highlight_range = color_range

class UnrecTokenList():
    def __init__(self, filename, linenumber, token_list):
        self.filename = filename
        self.linenumber = linenumber
        self.token_list = token_list

    def GetAsString(self):
        ret_string = self.filename + ":" + str(self.linenumber) + ": "
        for token in self.token_list:
            ret_string += "\"" + token + "\" "
        return ret_string

    def TrimFilename(self, path_len):
        self.filename = self.filename[path_len:]

def GetTreeListFromPointDefs(point_defs, low, high, static):
    treedata = {}
    unrec_tokens = []
    console_points = {}
    for pointdef in point_defs:
        filename = pointdef.GetPath()
        linenumber = pointdef.GetLineNumber()
        root_item = treedata
        path_list = filename.split('/')
        unrec_tokens_list = pointdef.GetArgumentList().GetUnrecTokens()
        if unrec_tokens_list:
            unrec_tokens.append(UnrecTokenList(filename, linenumber,
                                               unrec_tokens_list))
        if len(path_list) == 1:
            if path_list[0] == 'CONSOLE':
                console_points[linenumber] = FileTreeItem(pointdef, low, high, static)
                continue
            path_sep = '\\'
            path_list = filename.split('\\')
        else:
            path_sep = '/'
        listiter = iter(path_list)
        path_item = next(listiter)
        for next_item in listiter:
            if path_item not in root_item:
                root_item[path_item] = {}
            root_item = root_item[path_item]
            path_item = next_item
        if path_item not in root_item:
            root_item[path_item] = {}
        if linenumber not in root_item[path_item]:
            point = FileTreeItem(pointdef, low, high, static)
            root_item[path_item][linenumber] = point
    root_item = treedata
    root_path = ""
    while len(root_item) == 1:
        root_path += root_item.keys()[0] + path_sep
        root_item = root_item.itervalues().next()
    if console_points:
        root_item['CONSOLE'] = console_points
    for unrec_token in unrec_tokens: unrec_token.TrimFilename(len(root_path))
    return root_item,root_path,path_sep,unrec_tokens

class PropertyWindow(wx.Panel):
    def __init__(self,parent):
        wx.Panel.__init__(self,parent)

class FileTreeItem():
    def __init__(self, pointdef, low, high, static):
        self.pointdef = pointdef
        self.enabled = True
        self.low = low
        self.high = high
        self.static = static

    def GetColour(self):
        if self.GetTypeId() == InstrumentationModel.PointDefinition.type_low:
            return eval(self.low) if self.GetEnabled() else "GREY"
        if self.GetTypeId() == InstrumentationModel.PointDefinition.type_static:
            return eval(self.static) if self.GetEnabled() else "GREY"
        return eval(self.high) if self.GetEnabled() else "GREY"

    def GetEnabled(self):
        return self.enabled

    def Disable(self):
        self.enabled = False

    def Enable(self):
        self.enabled = True

    def GetFunctionName(self):
        return self.pointdef.GetFunction()

    def GetPointId(self):
        return self.pointdef.GetID()

    def GetTypeId(self):
        return self.pointdef.GetType()

    def GetCount(self):
        return self.pointdef.GetCount()

    def GetNCalls(self):
        return self.pointdef.GetNCalls()

    def GetPath(self):
        return self.pointdef.GetPath()

    def GetLineNumber(self):
        return self.pointdef.GetLineNumber()

    def GetFormatString(self):
        return self.pointdef.GetFormatString()

FileTreeChangedEvent, EVT_FILE_TREE_CHANGED = wx.lib.newevent.NewEvent()
FileTreeOpenEvent, EVT_FILE_TREE_OPEN = wx.lib.newevent.NewEvent()

class FileTree(wx.TreeCtrl, ContextMenu):
    def __init__(self, parent):
        wx.TreeCtrl.__init__(self, parent,
                             style=wx.TR_HIDE_ROOT|wx.TR_HAS_BUTTONS)
        ContextMenu.__init__(self)
        self.rootId = None
        self.MainWindow=parent.GetTopLevelParent()
        self.handleTreeChangeEvents = True
        self.blacklist_points=set()
        self.Bind(wx.EVT_TREE_ITEM_EXPANDED, self.OnTreeChanged)
        self.Bind(wx.EVT_TREE_ITEM_COLLAPSED, self.OnTreeChanged)
        self.Bind(wx.EVT_MENU, self.OnMenu)
        self.Bind(wx.EVT_LEFT_DCLICK, self.OnLeftDClick)
        self.ID_ENABLE = 1
        self.ID_DISABLE = 2
        self.ID_HIDE = 3
        self.ID_OPEN = 4
        self.ID_ALL_BUT_SELECTED_TREE = 5
        self.ID_ALL_BUT_SELECTED_FOLDER = 6
        self.ID_BlackList = 7
        self.count = 0


    def CreateContextMenu(self, menu, event):

        self.enable_menuitem = self._menu.Append(self.ID_ENABLE, "Enable",
                                "Enable points for filtering and make them visible")
        self.disable_menuitem = self._menu.Append(self.ID_DISABLE, "Disable",
                                "Disable points for filtering but leave them visible")
        self.hide_menuitem = self._menu.Append(self.ID_HIDE, "Hide",
                                "Hide and disable points for filtering")
        self.BlackList = self._menu.Append(self.ID_BlackList, "BlackList","BlackList Points")
        self.open_menuitem = self._menu.Append(self.ID_OPEN, "Open",
                                "Open in an editor")
        self.disable_all_but_selected_tree_menuitem = self._menu.Append(self.ID_ALL_BUT_SELECTED_TREE,
                                                        "Disable All but Selected in Tree")
        self.disable_all_but_selected_folder_menuitem = self._menu.Append(self.ID_ALL_BUT_SELECTED_FOLDER,
                                                        "Disable All but Selected in Folder")
        item_id = self.GetSelection()
        item_data = self.GetItemData(item_id)
        if item_data and item_data.GetData():
            value = item_data.GetData()
            if value.GetPointId() in self.blacklist_points:
                self.enable_menuitem.Enable(False)
                self.disable_menuitem.Enable(False)
            else:
                self.enable_menuitem.Enable(True)
                self.disable_menuitem.Enable(True)

    def OnTreeChanged(self, event):
        if self.handleTreeChangeEvents:
            evt = FileTreeChangedEvent()
            self.GetEventHandler().ProcessEvent(evt)
            
    def OnMenu(self, event):
        item_id = self.GetSelection()
        if event.GetId() == self.ID_OPEN:
            item_data = self.GetItemData(item_id)
            if item_data and item_data.GetData():
                value = item_data.GetData()
                evt = FileTreeOpenEvent(filepath=value.GetPath(),
                                        linenum=value.GetLineNumber())
                self.GetEventHandler().ProcessEvent(evt)
            return
        self.handleTreeChangeEvents = False
        if event.GetId() == self.ID_ENABLE:
            self.ExpandAllChildren(item_id)
        elif event.GetId() == self.ID_HIDE:
            self.CollapseAllChildren(item_id)
        elif event.GetId() == self.ID_ALL_BUT_SELECTED_TREE:
            self.DisableAllButSelectedTree(event, item_id, self.rootId)
        elif event.GetId() == self.ID_ALL_BUT_SELECTED_FOLDER:
            self.DisableAllButSelectedFolder(event, item_id, event.GetId())
        elif event.GetId() == self.ID_BlackList:
            self.BlackListPoints(event,item_id)
            return
        if self.ItemHasChildren(item_id):
            self.UpdateItemColourAllChildren(item_id, event.GetId())
        else:
            self.UpdateItemColour(item_id, event.GetId())
        evt = FileTreeChangedEvent()
        self.GetEventHandler().ProcessEvent(evt)

    def BlackListPoints(self,event,item_id):
        item_data = self.GetItemData(item_id)
        if item_data and item_data.GetData():
                value=item_data.GetData()
                if value.GetPointId() in self.blacklist_points:
                    self.blacklist_points.remove(value.GetPointId())
                    self.SetItemBold(item_id, False)
                else:
                    self.blacklist_points.add(value.GetPointId())
                    self.SetItemBold(item_id, True)
        self.handleTreeChangeEvents=True
        self.OnTreeChanged(event)

    def OnLeftDClick(self, event):
        item_id = self.GetSelection()
        item_data = self.GetItemData(item_id)
        if self.ItemHasChildren(item_id):
            if self.IsExpanded(item_id):
                self.CollapseAllChildren(item_id)
            else:
                self.ExpandAllChildren(item_id)
        else:
            if item_data:
                value = item_data.GetData()
                if value.GetPointId() in self.blacklist_points:
                    return
                if value.GetEnabled():
                    self.UpdateItemColour(item_id, self.ID_DISABLE)
                else:
                    self.UpdateItemColour(item_id, self.ID_ENABLE)
        evt = FileTreeChangedEvent()
        self.GetEventHandler().ProcessEvent(evt)

    def DisableAllButSelectedTree(self, event, item_id, root_id):

        def DisableAllExpandedFolders(self, item_id):
            child_id,cookie = self.GetFirstChild(item_id)
            while child_id.IsOk():
                if self.ItemHasChildren(child_id):
                    if self.IsExpanded(child_id):
                        self.UpdateItemColourAllChildren(child_id, self.ID_DISABLE)
                    if item_id == self.GetSelection():
                        self.UpdateItemColour(item_id, self.ID_ENABLE)
                child_id,cookie = self.GetNextChild(item_id, cookie)

        DisableAllExpandedFolders(self, root_id)
        self.UpdateItemColour(item_id, self.ID_ENABLE)
        self.handleTreeChangeEvents=True
        self.OnTreeChanged(event)

    def DisableAllButSelectedFolder(self, event, item_id, event_id):
        self.UpdateItemColourAllChildren(self.GetItemParent(item_id), self.ID_DISABLE)
        self.UpdateItemColour(item_id, self.ID_ENABLE)
        self.handleTreeChangeEvents=True
        self.OnTreeChanged(event)

    def UpdateItemColourAllChildren(self, item_id, event_id):
        child_id,cookie = self.GetFirstChild(item_id)
        while child_id.IsOk():
            if self.ItemHasChildren(child_id):
                self.UpdateItemColourAllChildren(child_id, event_id)
            else:
                self.UpdateItemColour(child_id, event_id)
            child_id,cookie = self.GetNextChild(item_id, cookie)

    def UpdateItemColour(self, item_id, event_id):
        item_data = self.GetItemData(item_id)
        if item_data and item_data.GetData():
            value = item_data.GetData()
            if event_id == self.ID_ENABLE:
                value.Enable()
            elif event_id == self.ID_DISABLE:
                value.Disable()
            elif event_id == self.ID_ALL_BUT_SELECTED_TREE:
                    value.Enable()
            colour = value.GetColour()
            self.SetItemTextColour(item_id, colour)

    def GetPointDefLabel(self, key, value):
        if self.MainWindow.tree_view_labels: 
            linenumber = str(value.GetLineNumber())
            classname,functionname = \
              GetClassAndFunction(value.GetFunctionName())
            point_def_label = str(value.GetCount()) + "/" + \
              str(value.GetNCalls())
            point_def_label = point_def_label.ljust(10)
            point_def_label = point_def_label + \
              classname + "::" + functionname + ":" + linenumber
        else:
            point_def_label = value.GetFormatString()
        return point_def_label

    def SetTreeList(self, treedata, sort_case, parentId=None):
        if parentId == None:
            self.DeleteAllItems()
            parentId = self.AddRoot('')
            self.rootId = parentId
        if sort_case:
            self.treedata_items = sorted(treedata.items())
        else:
            self.treedata_items = treedata.items()
        for key,value in self.treedata_items:
            if type(key) is int:
                point_def_label = self.GetPointDefLabel(key, value)
                item = self.AppendItem(parentId, point_def_label)
                colour = value.GetColour()
                self.SetItemTextColour(item, colour)
                self.SetItemData(item, wx.TreeItemData(value))
            else:
                childId = self.AppendItem(parentId, key)
                self.SetTreeList(value, sort_case, childId)

    def GetVisiblePoints(self, item_id=None, points=None):
        if points is None:
            points = set()
        if item_id is None:
            item_id = self.rootId
        child_id,cookie = self.GetFirstChild(item_id)
        while child_id.IsOk():
            item_data = self.GetItemData(child_id)
            if item_data and item_data.GetData():
                value = item_data.GetData()
                if value.GetEnabled():
                    points.add(value.GetPointId())
            else:
                if self.IsExpanded(child_id):
                    self.GetVisiblePoints(child_id, points)
            child_id,cookie = self.GetNextChild(item_id, cookie)
        return points

    def FindPointAndSelect(self, point_id, item_id=None):
        if item_id is None:
            item_id = self.rootId
        child_id,cookie = self.GetFirstChild(item_id)
        while child_id.IsOk():
            item_data = self.GetItemData(child_id)
            if item_data and item_data.GetData():
                value = item_data.GetData()
                if point_id == value.GetPointId():
                    self.SelectItem(child_id)
                    return True
            else:
                if self.FindPointAndSelect(point_id, child_id):
                    return True
            child_id,cookie = self.GetNextChild(item_id, cookie)
        return False

    def GetExpandedNodes(self,item_id=None,points=None):
        if points is None:
            points=[]
        if item_id is None:
            item_id = self.rootId
        child_id,cookie=self.GetFirstChild(item_id)
        while child_id.IsOk():
            if self.IsExpanded(child_id):
                points.append(self.GetItemText(child_id))
            child_id,cookie = self.GetNextChild(item_id, cookie)
        return points

    def SetTreeStructure(self,filelist):
        self.CollapseAll()
        if len(filelist) == 0 :
            return
        tree_root=self.rootId
        for file in filelist:
            if file == filelist[0]:
                child_id,cookie=self.GetFirstChild(tree_root)
            else :
                child_id,cookie=self.GetNextChild(tree_root, cookie)
            while child_id.IsOk():
                if self.GetItemText(child_id) == file:
                    self.Expand(child_id)
                    break
                child_id,cookie = self.GetNextChild(tree_root, cookie)

ThreadFilterChangeEvent, EVT_THREAD_FILTER_CHANGE = wx.lib.newevent.NewEvent()
A0FilterChangeEvent, EVT_A0_FILTER_CHANGE = wx.lib.newevent.NewEvent()
A1FilterChangeEvent, EVT_A1_FILTER_CHANGE = wx.lib.newevent.NewEvent()
CopyToClipboardEvent, EVT_COPY_TO_CLIPBOARD = wx.lib.newevent.NewEvent()

class DataPointGrid(wx.grid.Grid, ContextMenu):
    def __init__(self, parent):
        wx.grid.Grid.__init__(self, parent)
        ContextMenu.__init__(self)
        self.Bind(wx.EVT_MENU, self.OnMenu)
        self.DisableDragRowSize()
        self.MainWindow=parent.GetTopLevelParent()
        self.before_filteredpoints=[]
        self.after_filteredpoints=[]
        self.right_click_row = None
        self.copy_range = None

    def CreateContextMenu(self, menu, event):
        self.ID_COPY = 1
        self.copy_menuitem = self._menu.Append(self.ID_COPY, "Copy",
                                  "Copy the highlighted rows to the clipboard")
        self.ID_THREAD_FILTER = 2
        self.thread_menuitem = self._menu.Append(self.ID_THREAD_FILTER,
            "Thread Filter",
            "Copy the thread Id of the selected item to the Thread selection")
        self.ID_A0_FILTER = 3
        self.a0_menuitem = self._menu.Append(self.ID_A0_FILTER,
            "A0 Filter",
            "Copy the A0 value of the selected item to the A0 selection")
        self.ID_A1_FILTER = 4
        self.a1_menuitem = self._menu.Append(self.ID_A1_FILTER,
            "A1 Filter",
            "Copy the A1 value of the selected item to the A1 selection")
        self.ID_REMOVE_BEFORE_CLOCK = 5
        self.remove_before_clock = self._menu.Append(self.ID_REMOVE_BEFORE_CLOCK, \
            "Remove Before Clock","Remove messages with clock less than current value ")
        self.ID_REMOVE_AFTER_CLOCK = 6
        self.remove_after_clock = self._menu.Append(self.ID_REMOVE_AFTER_CLOCK, \
            "Remove After Clock","Remove messages with clock greater than current value ")
        self.ID_HEX = 7
        self.hex=self._menu.Append(self.ID_HEX, \
            "Hexadecimal","Convert Log to Hexadecimal values")
        self.ID_DEC = 8
        self.dec=self._menu.Append(self.ID_DEC, \
            "Decimal","Convert Log to Decimal values")
        if self.MainWindow.mode == "DEC":
            self._menu.Enable(self.ID_DEC,False)
            self._menu.Enable(self.ID_HEX,True)
        else:
            self._menu.Enable(self.ID_HEX,False)
            self._menu.Enable(self.ID_DEC,True)
        self.right_click_row = event.GetRow()

    def OnMenu(self, event):
        if not self.GetTable():
            return
        if event.GetId() == self.ID_THREAD_FILTER:
            value = self.GetTable().GetRowThreadId(self.right_click_row)
            evt = ThreadFilterChangeEvent(item_value=hex(value))
            self.GetEventHandler().ProcessEvent(evt)
        if event.GetId() == self.ID_A0_FILTER:
            value = self.GetTable().GetRowA0(self.right_click_row)
            if value != None:
                evt = A0FilterChangeEvent(item_value=str(value))
                self.GetEventHandler().ProcessEvent(evt)
        if event.GetId() == self.ID_A1_FILTER:
            value = self.GetTable().GetRowA1(self.right_click_row)
            if value != None:
                evt = A1FilterChangeEvent(item_value=str(value))
                self.GetEventHandler().ProcessEvent(evt)
        if event.GetId() == self.ID_COPY:
            # the condition checks if a block of logs is selected,if not then a single row is selected
            if self.GetSelectionBlockBottomRight() and self.GetSelectionBlockBottomRight() and not self.copy_range:
                self.copy_range = (self.GetSelectionBlockTopLeft()[0][0],self.GetSelectionBlockBottomRight()[0][0])
            else:
                self.copy_range = (self.right_click_row,self.right_click_row)
            data_string = ""
            for row_idx in range(self.copy_range[0], self.copy_range[1]+1):
                data_string = data_string + \
                  self.GetTable().GetStringFromRow(row_idx) + "\n"
            self.copy_range = None
            self.GetTable().SetRangeColour(None)
            evt = CopyToClipboardEvent(data_str=data_string)
            self.GetEventHandler().ProcessEvent(evt)
        if event.GetId() == self.ID_REMOVE_BEFORE_CLOCK:
            self.MainWindow.filtermenu.Enable(self.MainWindow.filtermenu_items["reset_clock_filters"].GetId(),True)
            selected_row = self.right_click_row
            clock_value = float(self.MainWindow.filteredpoints[selected_row].GetAdjustedClock())/1000000
            filteredpoints = []
            self.MainWindow.before_clock_caption.SetValue(str(clock_value))
            for filteredpoint in self.MainWindow.filteredpoints:
                if clock_value <= float(filteredpoint.GetAdjustedClock())/1000000:
                    filteredpoints.append(filteredpoint)
                else:
                    self.before_filteredpoints.append(filteredpoint)
            self.MainWindow.filteredpoints=filteredpoints
            self.MainWindow.SetFilteredPointsToGrid()
        if event.GetId() == self.ID_HEX:
            self.MainWindow.mode="HEX"
            self.MainWindow.SetFilteredPointsToGrid()
        if event.GetId() == self.ID_DEC:
            self.MainWindow.mode="DEC"
            self.MainWindow.SetFilteredPointsToGrid()
        if event.GetId() == self.ID_REMOVE_AFTER_CLOCK:
            self.MainWindow.filtermenu.Enable(self.MainWindow.filtermenu_items["reset_clock_filters"].GetId(),True)
            selected_row = self.right_click_row
            clock_value = float(self.MainWindow.filteredpoints[selected_row].GetAdjustedClock())/1000000
            filteredpoints = []
            self.MainWindow.after_clock_caption.SetValue(str(clock_value))
            for filteredpoint in self.MainWindow.filteredpoints:
                if clock_value >= float(filteredpoint.GetAdjustedClock())/1000000:
                    filteredpoints.append(filteredpoint)
                else:
                    self.after_filteredpoints.append(filteredpoint)
            self.MainWindow.filteredpoints=filteredpoints
            self.MainWindow.SetFilteredPointsToGrid()
        self.right_click_row = None

    def SetCopyRange(self, start, end):
        if start > end:
            start,end = end,start
        self.copy_range = (start,end)
        if self.GetTable():
            self.GetTable().SetRangeColour(self.copy_range)
            self.ForceRefresh()

    def ClearCopyRange(self):
        self.copy_range = None
        if self.GetTable():
            self.GetTable().SetRangeColour(self.copy_range)
            self.ForceRefresh()

    def SetTable(self, object, *attributes):
        self.tableRef = weakref.ref(object)
        return wx.grid.Grid.SetTable(self, object, *attributes, takeOwnership=True)

    def GetTable(self):
        return self.tableRef()

    def GetColSizes(self):
        sizes = []
        for col in range(self.GetNumberCols()):
            sizes.append(self.GetColSize(col))
        return sizes

    def SetColSizes(self, sizes):
        col = 0
        for sizeval in sizes:
            if col < self.GetNumberCols():
                self.SetColSize(col, sizeval)
                col = col + 1

class PropertiesGrid(wx.grid.Grid):
    def __init__(self, parent ,rows, cols):
        wx.grid.Grid.__init__(self, parent, -1)
        self.CreateGrid(rows,cols)
        self.SetSelectionMode(wx.grid.Grid.wxGridSelectRows)
        self.EnableEditing(False)
        self.SetCellHighlightPenWidth(0)
        self.SetRowLabelSize(0)
        self.SetColLabelSize(0)
        self.DisableDragRowSize()

class GeneralPane(wx.CollapsiblePane):
    def __init__(self, *args, **kwargs):
        wx.CollapsiblePane.__init__(self,*args,**kwargs)
        sizer = wx.BoxSizer(wx.VERTICAL)
        pane_field_values=["Name","Location","Source File","Function","Line #"]
        grid_rows=len(pane_field_values)
        grid_cols=2
        self.general_pane_grid=PropertiesGrid(self.GetPane(),grid_rows,grid_cols)
        for pane_field_index in range(len(pane_field_values)):
            self.general_pane_grid.SetCellValue(pane_field_index,0,pane_field_values[pane_field_index])
        sizer.Add(self.general_pane_grid,1,wx.EXPAND)
        self.GetPane().SetSizer(sizer)
        self.general_pane_grid.SetColSize(0,125)
        self.general_pane_grid.SetColSize(0,150)
        self.general_pane_grid.SetColSize(1,1500)
        self.general_pane_grid.ShowScrollbars(wx.SHOW_SB_NEVER,wx.SHOW_SB_NEVER)
        self.Bind(wx.EVT_COLLAPSIBLEPANE_CHANGED, self.OnChange)

    def OnChange(self, event):
        self.GetParent().GetParent().GetParent().Layout()

class StatisticsPane(wx.CollapsiblePane):
    def __init__(self, *args, **kwargs):
        wx.CollapsiblePane.__init__(self,*args,**kwargs)
        sizer = wx.BoxSizer(wx.VERTICAL)
        pane_field_values=["# Samples","# Calls","Total Bytes","Bytes/Items","Min Clock","Max Clock","Min Y","Max Y","Sum Y","Ave Y"]
        grid_rows=len(pane_field_values)
        grid_cols=2
        self.statistics_pane_grid=PropertiesGrid(self.GetPane(),grid_rows,grid_cols)
        for pane_field_index in range(len(pane_field_values)):
            self.statistics_pane_grid.SetCellValue(pane_field_index,0,pane_field_values[pane_field_index])
        sizer.Add(self.statistics_pane_grid,1,wx.EXPAND)
        self.statistics_pane_grid.SetColSize(0,125)
        self.statistics_pane_grid.SetColSize(0,150)
        self.statistics_pane_grid.SetColSize(1,1500)
        self.statistics_pane_grid.ShowScrollbars(wx.SHOW_SB_NEVER,wx.SHOW_SB_NEVER)
        self.GetPane().SetSizer(sizer)
        self.Bind(wx.EVT_COLLAPSIBLEPANE_CHANGED, self.OnChange)

    def OnChange(self, event):
        self.GetParent().GetParent().GetParent().Layout()

class AppearancePane(wx.CollapsiblePane):
    def __init__(self, *args, **kwargs):
        wx.CollapsiblePane.__init__(self,*args,**kwargs)
        sizer = wx.BoxSizer(wx.VERTICAL)
        pane_field_values=["Y Offset","Y Scale","Is Hidden","Symbol","Size","Colour"]
        grid_rows=len(pane_field_values)
        grid_cols=2
        self.appearance_pane_grid=PropertiesGrid(self.GetPane(),grid_rows,grid_cols)
        for pane_field_index in range(len(pane_field_values)):
            self.appearance_pane_grid.SetCellValue(pane_field_index,0,pane_field_values[pane_field_index])
        sizer.Add(self.appearance_pane_grid,1,wx.EXPAND)
        self.appearance_pane_grid.SetColSize(0,150)
        self.appearance_pane_grid.SetColSize(1,1500)
        self.appearance_pane_grid.ShowScrollbars(wx.SHOW_SB_NEVER,wx.SHOW_SB_NEVER)
        self.GetPane().SetSizer(sizer)
        self.Bind(wx.EVT_COLLAPSIBLEPANE_CHANGED, self.OnChange)

    def OnChange(self, event):
        self.GetParent().GetParent().GetParent().Layout()

class ArgumentsPane(wx.CollapsiblePane):
    def __init__(self, *args, **kwargs):
        wx.CollapsiblePane.__init__(self,*args,**kwargs)
        sizer = wx.BoxSizer(wx.VERTICAL)
        self.arguments_pane_grid=PropertiesGrid(self.GetPane(),0,2)
        sizer.Add(self.arguments_pane_grid,1,wx.EXPAND)
        self.arguments_pane_grid.SetColSize(0,150)
        self.arguments_pane_grid.SetColSize(1,1500)
        self.arguments_pane_grid.ShowScrollbars(wx.SHOW_SB_NEVER,wx.SHOW_SB_DEFAULT)
        self.GetPane().SetSizer(sizer)
        self.Bind(wx.EVT_COLLAPSIBLEPANE_CHANGED, self.OnChange)

    def OnChange(self, event):
        self.GetParent().GetParent().GetParent().Layout()

class SamplePropertiesPane(wx.CollapsiblePane):
#Present Inside Property Window,consists of Sample and Arguments Gridss
    def __init__(self, *args, **kwargs):
        wx.CollapsiblePane.__init__(self,*args,**kwargs)
        sizer = wx.BoxSizer(wx.VERTICAL)
        pane_field_values=["Index In DataBase","Index In DataSet","Thread ID","Clock","Session ID","VirtSkt ID","Description"]
        grid_rows=len(pane_field_values)
        grid_cols=2
        self.sample_properties_pane_grid=PropertiesGrid(self.GetPane(),grid_rows,grid_cols)
        for pane_field_index in range(len(pane_field_values)):
            self.sample_properties_pane_grid.SetCellValue(pane_field_index,0,pane_field_values[pane_field_index])
        sizer.Add(self.sample_properties_pane_grid,0,wx.EXPAND|wx.ALL)
        self.sample_properties_pane_grid.SetColSize(0,150)
        self.sample_properties_pane_grid.SetColSize(1,1500)
        self.sample_properties_pane_grid.ShowScrollbars(wx.SHOW_SB_NEVER,wx.SHOW_SB_NEVER)
        sizer.Add(ArgumentsPane(self.GetPane(),label="Arguments",style=wx.CP_NO_TLW_RESIZE),0,wx.EXPAND)
        self.GetPane().SetSizer(sizer)
        self.Bind(wx.EVT_COLLAPSIBLEPANE_CHANGED, self.OnChange)

    def OnChange(self, event):
        self.GetParent().Layout()

class ItemPropertiesPane(wx.CollapsiblePane):
#Present Inside Property window,cosnsists of general,statistics and appearance Grid
    def __init__(self, *args, **kwargs):
        wx.CollapsiblePane.__init__(self,*args,**kwargs)
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(GeneralPane(self.GetPane(),label="General",style=wx.CP_NO_TLW_RESIZE),0,wx.EXPAND)
        sizer.Add(StatisticsPane(self.GetPane(),label="Statistics",style=wx.CP_NO_TLW_RESIZE),0,wx.EXPAND)
        sizer.Add(AppearancePane(self.GetPane(),label="Appearance",style=wx.CP_NO_TLW_RESIZE),0,wx.EXPAND)
        self.GetPane().SetSizer(sizer)
        self.Bind(wx.EVT_COLLAPSIBLEPANE_CHANGED, self.OnChange)

    def OnChange(self, event):
        self.GetParent().Layout()
#Make entire window drop target for files
class MyFileDropTarget(wx.FileDropTarget):
    def __init__(self, window):
        wx.FileDropTarget.__init__(self)
        self.window = window

    def OnDropFiles(self, x, y, filenames):
        file = filenames[0]
        if file.endswith('.tar.gz'):
            tar = tarfile.open(file, "r:gz")
            for members in tar:
                if os.path.splitext(members.name)[1] == ".dat":
                    tar.extract(members.name)
                    self.window.Load(members.name)
                    shutil.rmtree('tmp')
                    break
        if file.endswith('.dat'):
            self.window.Load(file)
        if file.endswith('.tar'):
            tar = tarfile.open(file, "r:*")
            for members in tar:
                if os.path.splitext(members.name)[1] == ".dat":
                    tar.extract(members.name)
                    self.window.Load(members.name)
                    shutil.rmtree('tmp')
                    break

################################################################################
#
# The MainWindow creates all the other stuff
#
################################################################################
class MainWindow(wx.Frame):
    """The initial frame"""
    def __init__(self, parent, title,font_attributes):
        # Initialize some useful members and state
        self.dirname = ''
        wx.Frame.__init__(self, parent, title=title)
        self.column_sizes = [ 100, 100, 150, 100, 3000 ]
        self.window_size = [ 900, 600 ]
        self.datapoints = []
        self.thread_ids = []
        self.filteredpoints = []
        self.filtered_context = []
        self.sort_case = False
        self.tree_view_labels = False
        self.find_result = False
        self.loaded_desc_list = False
        self.unrec_tokens = []
        self.settings = { "SourceDir": "",
                          "EditorCmd": "",
                          "SearchModePlainText": False }
        self.mode="DEC"
        self.low_color = '(0, 0, 255, 255)'
        self.high_color = '(0, 0, 0, 255)'
        self.static_color = '(0, 255, 0, 255)'
        self.background_color = '(255, 255, 255, 255)'
        #check if custom font is set/or set if not go back to default
        if font_attributes["font_face"]!="wx.DEFAULT":
            wholeFont=wx.Font(font_attributes["font_point_size"],wx.DEFAULT, wx.NORMAL, wx.NORMAL, 0, font_attributes["font_face"])
            self.font_face=font_attributes["font_face"]
            self.font_point_size=font_attributes["font_point_size"]
            self.SetFont(wholeFont)
        else:
            self.font_point_size = "wx.DEFAULT"
            self.font_face = "wx.DEFAULT"
        self.statusbar = self.CreateStatusBar()
        self.SetWindowIcon()
        self.Bind(wx.EVT_CLOSE, self.OnClose)
        self.AddMenuBar()
        #The structure of the app consists of a main splitterwindow,left side of which consists  of another splitterwindow having treectrl and
        # grid.The right side consists of the property window
        self.grid_property_splitter = wx.SplitterWindow(self)
        self.table_tree_splitter = wx.SplitterWindow(self.grid_property_splitter)
        self.grid_property_splitter.SetMinimumPaneSize(20)
        self.property_window_panel= wx.Panel(self.grid_property_splitter)
        self.property_window=PropertyWindow(self.property_window_panel)
        property_window_panel_sizer=wx.BoxSizer(wx.VERTICAL)
        self.property_window_top_panel=wx.Panel(self.property_window)
        self.property_window_top_panel.SetBackgroundColour('LIGHT GREY')
        property_window_label=wx.StaticText(self.property_window_top_panel,label="Property Window",style=wx.ALIGN_LEFT)
        font = wx.Font(14, wx.DEFAULT,wx.NORMAL,wx.BOLD)
        property_window_label.SetFont(font)
        close_button=wx.Button(self.property_window_top_panel,size=(30,-1),label="X")
        close_button.Bind(wx.EVT_BUTTON, self.OnPropertyWindowCloseBtn)
        property_window_top_panel_sizer=wx.BoxSizer(wx.HORIZONTAL)
        property_window_top_panel_sizer.Add(close_button,0,flag=wx.ALIGN_LEFT)
        property_window_top_panel_sizer.Add(property_window_label,1,flag=wx.EXPAND)
        self.property_window_top_panel.SetSizer(property_window_top_panel_sizer)
        self.property_window_panel.SetSizer(property_window_panel_sizer)
        property_window_panel_sizer.Add(self.property_window,1,wx.EXPAND)
        property_window_sizer=wx.BoxSizer(wx.VERTICAL)
        property_window_sizer.Add(self.property_window_top_panel,0,wx.EXPAND | wx.ALL,5)
        #Adding collapsible panes to the property window
        property_window_sizer.Add(ItemPropertiesPane(self.property_window,label="Item Property",style=wx.CP_NO_TLW_RESIZE),0,wx.EXPAND)
        property_window_sizer.Add(SamplePropertiesPane(self.property_window,label="Sample Property",style=wx.CP_NO_TLW_RESIZE),0,wx.EXPAND)
        self.property_window.SetSizer(property_window_sizer)
        self.left_panel = wx.Panel(self.table_tree_splitter)
        # The tree which holds all the instrumentation points
        self.tree_list = FileTree(self.left_panel)
        self.tree_list.Bind(EVT_FILE_TREE_CHANGED, self.OnTreeChanged)
        self.tree_list.Bind(EVT_FILE_TREE_OPEN, self.OnTreeOpen)
        left_panel_sizer = wx.BoxSizer(wx.VERTICAL)
        left_panel_sizer.Add(self.tree_list, 1, wx.EXPAND)
        self.left_panel.SetSizer(left_panel_sizer)
        self.tabs_notebook=wx.Notebook(self.table_tree_splitter)
        self.right_panel = wx.Panel(self.tabs_notebook)
        self.graph_panel =wx.Panel(self.tabs_notebook)
        self.find_panel = wx.Panel(self.right_panel,style=wx.BORDER_RAISED)
        self.find_panel.Hide()
        #Accelerator table is used to detect keyboard shortcut ctrl+f and call the OnKeySearchMethod
        self.search_key_id = wx.NewId()
        self.right_panel.Bind(wx.EVT_MENU, self.OnMenuItem,id=self.search_key_id)
        accel_tbl = wx.AcceleratorTable([(wx.ACCEL_CTRL,  ord('F'), self.search_key_id)])
        self.SetAcceleratorTable(accel_tbl)
        find_sizer=wx.BoxSizer(wx.HORIZONTAL)
        # find_sizer.Add(self.find_panel)
        find_panel_sizer=wx.BoxSizer(wx.HORIZONTAL)
        self.find_panel_close=wx.Button(self.find_panel,size=(30,-1),label="X")
        self.find_panel_close.Bind(wx.EVT_BUTTON,self.OnCLoseFindPanel)
        self.find_panel_search_box=wx.TextCtrl(self.find_panel,size=(275,-1), style=wx.TE_PROCESS_ENTER)
        self.find_label = wx.StaticText(self.find_panel,label="Find:")
        self.find_panel_up = wx.Button(self.find_panel,label="Previous")
        self.find_panel_up.Bind(wx.EVT_BUTTON,self.OnFindSearchUp)
        self.find_panel_down = wx.Button(self.find_panel,label="Next")
        self.find_panel_down.Bind(wx.EVT_BUTTON, self.CallFindSearchDown)
        self.find_panel_search_box.Bind(wx.EVT_TEXT_ENTER, self.CallFindSearchDown)
        find_panel_sizer.Add(self.find_panel_close)
        find_panel_sizer.AddSpacer(10)
        find_panel_sizer.Add(self.find_label)
        find_panel_sizer.Add(self.find_panel_search_box)
        find_panel_sizer.AddSpacer(10)
        find_panel_sizer.Add(self.find_panel_up)
        find_panel_sizer.Add(self.find_panel_down)
        self.find_panel.SetSizer(find_panel_sizer)
        #drawing the graph canvas
        # self.s=Figure()
        # self.graph_view_axes = self.figure.add_subplot(111)
        # self.x_axis=set()
        # self.canvas = FigureCanvas(self.graph_panel, -1,self.figure)
        # self.figure.canvas.mpl_connect('pick_event', self.OnPointGraphClick)
        # self.figure.canvas.mpl_connect('scroll_event',self.OnZoom)
        canvas_sizer = wx.BoxSizer(wx.VERTICAL)
        # canvas_sizer.Add(self.canvas, 1, wx.LEFT | wx.TOP | wx.EXPAND)
        # self.graph_panel.SetSizer(canvas_sizer)
        # toolBar=NavigationToolbar2Wx(self.canvas)
        # toolBar.Realize()
        # canvas_sizer.Add(toolBar,0,wx.LEFT | wx.EXPAND)
        # toolBar.Update()
        self.tabs_notebook.AddPage(self.right_panel,"Log View")
        self.tabs_notebook.AddPage(self.graph_panel,"Graph View")
        # The table which shows the data points
        self.table_labels = ('ThreadId', 'Clock', 'Method', 'Session Id','Description')
        self.table_grid = DataPointGrid(self.right_panel)
        self.table_grid.CreateGrid(0, 0)
        self.table_grid.SetSelectionMode(wx.grid.Grid.wxGridSelectRows)
        self.table_grid.EnableEditing(False)
        self.table_grid.SetCellHighlightPenWidth(0)
        self.table_grid.SetColLabelAlignment(wx.ALIGN_LEFT, wx.ALIGN_CENTRE)
        self.table_grid.Bind(wx.grid.EVT_GRID_CELL_LEFT_CLICK, \
                             self.OnGridSelect)
        self.table_grid.Bind(wx.grid.EVT_GRID_LABEL_LEFT_CLICK, \
                             self.OnGridSelect)
        self.table_grid.Bind(wx.grid.EVT_GRID_CELL_LEFT_DCLICK, \
                             self.OnGridSelect)
        self.table_grid.Bind(wx.grid.EVT_GRID_CMD_COL_SIZE, \
                             self.OnGridColumnResize)
        self.table_grid.Bind(wx.EVT_KEY_DOWN, self.OnGridKey)
        self.table_grid.Bind(wx.EVT_KEY_UP, self.OnGridKeyUp)
        self.table_grid.Bind(EVT_THREAD_FILTER_CHANGE, \
                             self.OnThreadFilterChange)
        self.table_grid.Bind(EVT_A0_FILTER_CHANGE, \
                             self.OnA0FilterChange)
        self.table_grid.Bind(EVT_A1_FILTER_CHANGE, \
                             self.OnA1FilterChange)
        self.table_grid.Bind(EVT_COPY_TO_CLIPBOARD, self.OnCopyToClipboard)
        # layout of the splitter uses panels and box sizers
        right_panel_sizer = wx.BoxSizer(wx.VERTICAL)
        right_panel_sizer.Add(self.table_grid, 1, wx.EXPAND)
        right_panel_sizer.Add(self.find_panel,0, flag=wx.EXPAND)
        self.right_panel.SetSizer(right_panel_sizer)
        self.grid_shifted = False
        self.grid_selected_row = 0
        self.grid_property_splitter.SplitVertically(self.table_tree_splitter,self.property_window_panel,-10)
        self.table_tree_splitter.SplitVertically(self.left_panel,
                                                 self.tabs_notebook, 100)
        self.table_tree_splitter.SetMinimumPaneSize(20)
        search_sizer = wx.BoxSizer(wx.HORIZONTAL)
        # create the controls at the top
        search_label = wx.StaticText(self, label=" Search Expr:")
        self.search_caption = wx.ComboBox(self, style=wx.TE_PROCESS_ENTER, size=(100,-1))
        self.search_caption.SetToolTip(
            wx.ToolTip("Regular expression for filter or search"))
        self.search_caption.Bind(wx.EVT_TEXT_ENTER, self.OnSearchEnter)
        self.search_caption.Bind(wx.EVT_COMBOBOX, self.OnFilter)
        self.search_button_up = wx.Button(self,label=u"\u2191",size=(30,-1))
        self.filter_tree = wx.ToggleButton(self,label="Tr",size=(30,-1),name="treeFilterButton")
        self.filter_tree.SetToolTip(wx.ToolTip("Filter by tree view"))
        self.filter_tree.Disable()
        self.filter_tree.Bind(wx.EVT_TOGGLEBUTTON,self.OnTreeFilter)
        self.search_button_up.SetToolTip(
            wx.ToolTip("Search backward using Search Expr"))
        self.search_button_up.Disable()
        self.search_button_up.Bind(wx.EVT_BUTTON, self.OnSearchUp)
        self.search_button_down = wx.Button(self,label=u"\u2193",size=(30,-1))
        self.search_button_down.SetToolTip(
            wx.ToolTip("Search forward using Search Expr"))
        self.search_button_down.Disable()
        self.search_button_down.Bind(wx.EVT_BUTTON, self.OnSearchDown)
        before_clock_label = wx.StaticText(self, label="Bf Clk")
        self.before_clock_caption=wx.TextCtrl(self, style=wx.TE_READONLY,size=(75,-1))
        self.before_clock_caption.SetToolTip(wx.ToolTip("Before Clock Value"))
        after_clock_label = wx.StaticText(self, label="Af Clk")
        self.after_clock_caption=wx.TextCtrl(self, style=wx.TE_READONLY,size=(75,-1))
        self.after_clock_caption.SetToolTip(wx.ToolTip("After Clock Value"))
        #Add filter buttons
        self.filter_low_freq = wx.ToggleButton(self, label="Lo", size=(30, -1))
        self.filter_low_freq.Disable()
        self.filter_low_freq.Bind(wx.EVT_TOGGLEBUTTON, self.OnFilterLowFreq)
        self.filter_low_freq.SetToolTip(wx.ToolTip("Exclude low frequency"))
        self.filter_high_freq = wx.ToggleButton(self, label="Hi", size=(30, -1))
        self.filter_high_freq.Disable()
        self.filter_high_freq.Bind(wx.EVT_TOGGLEBUTTON, self.OnFilterHighFreq)
        self.filter_high_freq.SetToolTip(wx.ToolTip("Exclude high frequency"))
        self.filter_static = wx.ToggleButton(self, label = "Static", size=(50, -1))
        self.filter_static.Disable()
        self.filter_static.Bind(wx.EVT_TOGGLEBUTTON, self.OnFilterStatic)
        self.filter_static.SetToolTip(wx.ToolTip("Exclude static frequency"))
        self.filter_blacklist = wx.ToggleButton(self, label="BL", size=(30, -1))
        self.filter_blacklist.SetToolTip(wx.ToolTip("Blacklist points"))
        self.filter_blacklist.Disable()
        self.filter_blacklist.Bind(wx.EVT_TOGGLEBUTTON, self.OnBlackList)
        search_sizer.Add(search_label, flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.search_caption,
                         flag=wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(before_clock_label,flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.before_clock_caption,flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(after_clock_label,flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.after_clock_caption,flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.search_button_up, flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.search_button_down, flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(wx.StaticLine(self, style=wx.LI_VERTICAL), 0, wx.ALL | wx.EXPAND, 5)
        search_sizer.Add(self.filter_low_freq, flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.filter_high_freq, flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.filter_static, flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.filter_tree, flag=wx.ALIGN_LEFT | \
                        wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.filter_blacklist, flag=wx.ALIGN_LEFT | \
                        wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(wx.StaticLine(self, style=wx.LI_VERTICAL), 0, wx.ALL | wx.EXPAND, 5)
        #Add context button/combo box 
        self.context_button = wx.ToggleButton(self, label="*", size=(30, -1))
        self.context_button.Disable()
        self.context_button.Bind(wx.EVT_TOGGLEBUTTON, self.OnFilter)
        self.context_button.SetToolTip(wx.ToolTip("Include DataPoint context"))
        self.context_caption = wx.ComboBox(self, style=wx.TE_PROCESS_ENTER, size=(50, -1))
        self.context_caption.SetToolTip(wx.ToolTip("Number of extra DataPoints to include"))
        self.context_caption.Disable()
        self.context_caption.Bind(wx.EVT_TEXT, self.OnContextValue)
        self.context_value = 0
        search_sizer.Add(self.context_button, flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.context_caption, flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_label = wx.StaticText(self, label=" ThreadId:")
        self.thread_caption = wx.ComboBox(self, style=wx.CB_READONLY, \
                                          size=(75,-1))
        self.thread_caption.SetToolTip(
            wx.ToolTip("Thread identifier used for filtering"))
        self.thread_caption.Bind(wx.EVT_COMBOBOX, self.OnFilter)
        search_sizer.Add(search_label, flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.thread_caption,
                         flag=wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL)

        a0_label = wx.StaticText(self, label=" a0:")
        self.a0_caption = wx.ComboBox(self, style=wx.TE_PROCESS_ENTER, size=(50,-1))
        self.a0_caption.SetToolTip(
            wx.ToolTip("a0 value used for filtering"))
        self.a0_caption.Bind(wx.EVT_TEXT_ENTER, self.OnA0Enter)
        self.a0_caption.Bind(wx.EVT_COMBOBOX, self.OnFilter)
        search_sizer.Add(a0_label, flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.a0_caption,
                         flag=wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL)
        a1_label = wx.StaticText(self, label=" a1:")
        self.a1_caption = wx.ComboBox(self, style=wx.TE_PROCESS_ENTER, size=(50,-1))
        self.a1_caption.SetToolTip(
            wx.ToolTip("a1 value used for filtering"))
        self.a1_caption.Bind(wx.EVT_TEXT_ENTER, self.OnA1Enter)
        self.a1_caption.Bind(wx.EVT_COMBOBOX, self.OnFilter)
        search_sizer.Add(a1_label, flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.a1_caption,
                         flag=wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL)

        args_label = wx.StaticText(self, label=" Args Expr:")
        self.args_caption = wx.ComboBox(self, style=wx.TE_PROCESS_ENTER, size=(100,-1))
        self.args_caption.SetToolTip(
            wx.ToolTip("Arguments python expression used for filtering"))
        self.args_caption.Bind(wx.EVT_TEXT_ENTER, self.OnArgsEnter)
        self.args_caption.Bind(wx.EVT_COMBOBOX, self.OnFilter)
        search_sizer.Add(args_label, flag=wx.ALIGN_LEFT | \
                         wx.ALIGN_CENTER_VERTICAL)
        search_sizer.Add(self.args_caption,
                         flag=wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL)

        self.grid_text = wx.TextCtrl(self, style=wx.TE_READONLY)
        self.grid_text.SetToolTip(
            wx.ToolTip("Description field of selected point"))
        search_sizer.Add(self.grid_text, proportion=1,
                         flag=wx.ALIGN_LEFT | wx.ALIGN_CENTER_VERTICAL | wx.EXPAND)

        #Set MainWindow as drop target for files
        drop_target = MyFileDropTarget(self)
        self.SetDropTarget(drop_target)
        #stuff everything into a final sizer and fit it into the window
        sizer = wx.BoxSizer(wx.VERTICAL)
        #intially property window should not be visible
        self.grid_property_splitter.Unsplit(toRemove=self.property_window_panel)
        sizer.Add(search_sizer, 0, flag=wx.EXPAND)
        sizer.Add(self.grid_property_splitter,1,flag=wx.EXPAND)
        self.SetSizer(sizer)
        self.SetAutoLayout(1)
        sizer.Fit(self)
        self.Show(True)

    def OnContextValue(self, event):
        def is_number(s):
            try:
                float(s)
                return True
            except ValueError: "Incorrect type, integer required"
            pass
            try:
                unicodedata.numeric(s)
                return True
            except (TypeError, ValueError): "Incorrect type, integer required"
            pass
            return False
        if is_number(self.context_caption.GetValue()):
            self.context_value = int(self.context_caption.GetValue())
        if self.context_button.GetValue():
            self.OnFilter(event)

    def OnTreeFilter(self,event):
        state = event.GetEventObject().GetValue()
        if state:
            self.filtermenu_items["by_file_menuitem"].Check(True)
            self.OnFilter(event)
        else:
            self.filtermenu_items["by_file_menuitem"].Check(False)
            self.OnFilter(event)

    def OnBlackList(self,event):
        state = event.GetEventObject().GetValue()
        if state:
            self.filtermenu_items["blacklist"].Check(True)
            blacklist_points = self.tree_list.blacklist_points
            self.OnFilter(event)
        else:
            self.filtermenu_items["blacklist"].Check(False)
            self.OnFilter(event)

    def OnFilterLowFreq(self, event):
        state = event.GetEventObject().GetValue()
        if state:
            self.filtermenu_items["by_low_freq"].Check(True)
            self.OnFilter(event)
        else:
            self.filtermenu_items["by_low_freq"].Check(False)
            self.OnFilter(event)

    def OnFilterHighFreq(self, event):
        state = event.GetEventObject().GetValue()
        if state:
            self.filtermenu_items["by_high_freq"].Check(True)
            self.OnFilter(event)
        else:
            self.filtermenu_items["by_high_freq"].Check(False)
            self.OnFilter(event)

    def OnFilterStatic(self, event):
        state = event.GetEventObject().GetValue()
        if state:
            self.filtermenu_items["by_static_freq"].Check(True)
            self.OnFilter(event)
        else:
            self.filtermenu_items["by_static_freq"].Check(False)
            self.OnFilter(event)

    def OnA0Enter(self, event):
        currstring = self.a0_caption.GetValue()
        if self.a0_caption.FindString(currstring) != wx.NOT_FOUND:
            return
        if self.a0_caption.GetCount() == 10:
            self.a0_caption.Delete(9)
        self.a0_caption.Insert(currstring, 0)
        if (self.filtermenu_items["by_a0"].IsChecked()):
            self.OnFilter(event)
        if self.highlightmenu_items["by_a0"].IsChecked():
            self.OnHighlight(event)

    def OnA1Enter(self, event):
        currstring = self.a1_caption.GetValue()
        if self.a1_caption.FindString(currstring) != wx.NOT_FOUND:
            return
        if self.a1_caption.GetCount() == 10:
            self.a1_caption.Delete(9)
        self.a1_caption.Insert(currstring, 0)
        if self.filtermenu_items["by_a1"].IsChecked():
            self.OnFilter(event)
        if self.highlightmenu_items["by_a1"].IsChecked():
            self.OnHighlight(event)

    def OnArgsEnter(self, event):
        currstring = self.args_caption.GetValue()
        if self.args_caption.FindString(currstring) != wx.NOT_FOUND:
            return
        if self.args_caption.GetCount() == 10:
            self.args_caption.Delete(9)
        self.args_caption.Insert(currstring, 0)
        if self.filtermenu_items["by_args"].IsChecked():
            self.OnFilter(event)
        if self.highlightmenu_items["by_args"].IsChecked():
            self.OnHighlight(event)

    def OnCopyToClipboard(self, event):
        data_str = event.data_str
        if wx.TheClipboard.Open():
            wx.TheClipboard.SetData(wx.TextDataObject(data_str))
            wx.TheClipboard.Close()

    # def OnZoom(self,event):
    #     base_scale=1.2
    #     cur_xlim = self.graph_view_axes.get_xlim()
    #     cur_ylim = self.graph_view_axes.get_ylim()
    #     xdata = event.xdata
    #     ydata = event.ydata
    #     if (xdata or ydata) is None:
    #         return
    #     x_left = xdata - cur_xlim[0]
    #     x_right = cur_xlim[1] - xdata
    #     y_top = ydata - cur_ylim[0]
    #     y_bottom = cur_ylim[1] - ydata
    #     if event.button == 'up':
    #         scale_factor = 1/base_scale
    #     elif event.button == 'down':
    #         scale_factor = base_scale
    #     else:
    #         scale_factor = 1
    #     self.graph_view_axes.set_xlim([xdata - x_left*scale_factor,
    #                 xdata + x_right*scale_factor])
    #     self.graph_view_axes.set_ylim([ydata - y_top*scale_factor,
    #                 ydata + y_bottom*scale_factor])
    #     self.figure.canvas.draw()
    def OnCLoseFindPanel(self,event):
        self.find_result = False
        self.statusbar.SetStatusText("")
        self.find_panel.Hide()
        self.right_panel.Layout()

    def OnThreadFilterChange(self, event):
        thread_id = event.item_value
        self.thread_caption.SetValue(thread_id)
        if self.filtermenu_items["by_sel_thread"].IsChecked():
            self.OnFilter(event)
        if self.highlightmenu_items["by_sel_thread"].IsChecked():
            self.OnHighlight(event)

    def OnA0FilterChange(self, event):
        a0_value = event.item_value
        self.a0_caption.SetValue(a0_value)
        if (self.filtermenu_items["by_a0"].IsChecked()):
            self.OnFilter(event)
        if self.highlightmenu_items["by_a0"].IsChecked():
            self.OnHighlight(event)

    def OnA1FilterChange(self, event):
        a1_value = event.item_value
        self.a1_caption.SetValue(a1_value)
        if self.filtermenu_items["by_a1"].IsChecked():
            self.OnFilter(event)
        if self.highlightmenu_items["by_a1"].IsChecked():
            self.OnHighlight(event)

    def OnFindSearchUp(self, event):
        currstring = self.find_panel_search_box.GetValue()
        starting_row = self.table_grid.GetGridCursorRow()
        filteredpoints_len = len(self.filteredpoints)
        row=[]
        datapoint_item_index_dict={}
        datapoint_vector=InstrumentationModel.DataPointVector()

        self.DisableFilterHighlightMenus()
        for item_index in reversed(range(0, starting_row)):
            datapoint_item_index_dict[self.filteredpoints[item_index].GetUniqueID()]=item_index

        row=self.parser.FindSearch(self.filteredpoints[0:starting_row],str(currstring),"up")
        row_found = False
        if row:
            row_found=True
            datapoint=row[0]
            item_index=datapoint_item_index_dict[datapoint.GetUniqueID()]
        if row_found:
            self.find_result = True
            self.selected_sample_number = \
              int(self.table_grid.GetRowLabelValue(item_index))
            self.table_grid.SelectRow(item_index)
            self.table_grid.SetGridCursor(item_index, 0)
            self.table_grid.MakeCellVisible(item_index, 0)
            self.statusbar.SetStatusText("Row matched")
            self.ShowOrHideSearchButtons(item_index)
            self.EnableFilterHighlightMenus()
            return

        self.EnableFilterHighlightMenus()
        self.search_button_up.Disable()
        self.find_panel_up.Disable()
        self.statusbar.SetStatusText("Done searching")

    def OnFindSearchDown(self, event, any_result):
        currstring = self.find_panel_search_box.GetValue()
        starting_row = self.table_grid.GetGridCursorRow()
        filteredpoints_len = len(self.filteredpoints)
        row=[]
        datapoint_item_index_dict={}
        self.DisableFilterHighlightMenus()
        for item_index in range(starting_row + 1, filteredpoints_len):
            datapoint_item_index_dict[self.filteredpoints[item_index].GetUniqueID()]=item_index
        row_found = False
        row=self.parser.FindSearch(self.filteredpoints[starting_row+1:],str(currstring),"down")
        if row:
            row_found=True
            datapoint=row[0]
            item_index=datapoint_item_index_dict[datapoint.GetUniqueID()]
        if row_found:
            self.find_result = True
            self.selected_sample_number = \
              int(self.table_grid.GetRowLabelValue(item_index))
            self.table_grid.SelectRow(item_index)
            self.table_grid.SetGridCursor(item_index, 0)
            self.table_grid.MakeCellVisible(item_index, 0)
            self.statusbar.SetStatusText("Row matched")
            self.ShowOrHideSearchButtons(item_index)
            self.EnableFilterHighlightMenus()
            return

        self.EnableFilterHighlightMenus()
        self.search_button_down.Disable()
        self.find_panel_down.Disable()
        self.statusbar.SetStatusText("Done searching")
        
    def OnSearchUp(self, event):
        currstring = self.search_caption.GetValue()
        pattern = re.compile(currstring)
        starting_row = self.table_grid.GetGridCursorRow()
        search_mode_plain_text = self.settings["SearchModePlainText"]
        filteredpoints_len = len(self.filteredpoints)

        self.DisableFilterHighlightMenus()
        for item_index in reversed(range(0, starting_row)):
            item = self.filteredpoints[item_index]
            row_found = False
            malformed = False
            try:
                if search_mode_plain_text:
                    if currstring in item.GetDescription():
                        row_found = True
                else:
                    if pattern.match(item.GetDescription()):
                        row_found = True
            except UnicodeDecodeError:
                self.statusbar.SetStatusText("Malformed string at Row=%d" % item_index)
                row_found = True
                malformed = True
                       
            if row_found:
                self.selected_sample_number = \
                  int(self.table_grid.GetRowLabelValue(item_index))
                self.table_grid.SelectRow(item_index)
                self.table_grid.SetGridCursor(item_index, 0)
                self.table_grid.MakeCellVisible(item_index, 0)
                if not malformed:
                    self.statusbar.SetStatusText("Row matched")
                self.ShowOrHideSearchButtons(item_index)
                self.EnableFilterHighlightMenus()
                return

            if (item_index % random.randint(100,500)) == 0:
                self.FilterYield(item_index)

        self.EnableFilterHighlightMenus()
        self.search_button_up.Disable()
        self.statusbar.SetStatusText("Done searching")

    def SetWindowIcon(self):
        if sys.platform == "darwin" or sys.platform == "linux2":
            return
        if getattr(sys, 'frozen', False):
            dir_ = os.path.dirname(sys.executable)
        else:
            dir_ = os.path.dirname(os.path.realpath(__file__))
        icon_path = os.path.join(dir_, "InstrumentationBrowser.ico")
        icon = wx.EmptyIcon()
        icon.CopyFromBitmap(wx.Bitmap(icon_path, wx.BITMAP_TYPE_ANY))
        self.SetIcon(icon)

    def OnPointGraphClick(self,event):
        test_list=list(self.graph_tree_plot_points)
        index=int(event.ind[0])
        point_id=self.graph_tree_plot_points[index].GetPointID()
        self.tree_list.FindPointAndSelect(point_id)

    def CallFindSearchDown(self, event):
        self.OnFindSearchDown(event, self.find_result)


    def OnSearchDown(self, event):
        currstring = self.search_caption.GetValue()
        pattern = re.compile(currstring)
        starting_row = self.table_grid.GetGridCursorRow()
        search_mode_plain_text = self.settings["SearchModePlainText"]
        filteredpoints_len = len(self.filteredpoints)

        self.DisableFilterHighlightMenus()
        for item_index in range(starting_row + 1, filteredpoints_len):
            item = self.filteredpoints[item_index]
            row_found = False
            malformed = False
            try:
                if search_mode_plain_text:
                    if currstring in item.GetDescription():
                        row_found = True
                else:
                    if pattern.match(item.GetDescription()):
                        row_found = True
            except UnicodeDecodeError:
                self.statusbar.SetStatusText("Malformed string at Row=%d" % item_index)
                row_found = True
                malformed = True
        
            if row_found:
                self.selected_sample_number = \
                  int(self.table_grid.GetRowLabelValue(item_index))
                self.table_grid.SelectRow(item_index)
                self.table_grid.SetGridCursor(item_index, 0)
                self.table_grid.MakeCellVisible(item_index, 0)
                if not malformed:
                    self.statusbar.SetStatusText("Row matched")
                self.ShowOrHideSearchButtons(item_index)
                self.EnableFilterHighlightMenus()
                return

            if (item_index % random.randint(100,500)) == 0:
                self.FilterYield(item_index)

        self.EnableFilterHighlightMenus()
        self.search_button_down.Disable()
        self.statusbar.SetStatusText("Done searching")

    def OnSearchEnter(self, event):
        currstring = self.search_caption.GetValue()
        if self.search_caption.FindString(currstring) != wx.NOT_FOUND:
            return
        if self.search_caption.GetCount() == 10:
            self.search_caption.Delete(9)
        self.search_caption.Insert(currstring, 0)
        if self.filtermenu_items["by_search_expr"].IsChecked():
            self.OnFilter(event)
        if self.highlightmenu_items["by_search_expr"].IsChecked():
            self.OnHighlight(event)

    def OnTreeChanged(self, event):
        if self.filtermenu_items["by_file_menuitem"].IsChecked() or \
          self.highlightmenu_items["by_file_menuitem"].IsChecked():
          treepoints = self.tree_list.GetVisiblePoints()
          if self.filtermenu_items["by_file_menuitem"].IsChecked():
              self.OnFilter(event)
          if self.highlightmenu_items["by_file_menuitem"].IsChecked():
                self.OnHighlight(event)
        """below code is commeneted as work is still going on the graph view"""
        # self.x_axis.clear()
        # self.graph_view_axes.clear()
        # self.graph_view_axes.set_xlabel("Clock")
        # treepoints=self.tree_list.GetVisiblePoints()
        # self.graph_tree_point_defs=treepoints
        # filteredpoints= self.FilterDataPointsByIds(self.datapoints,treepoints)
        # self.graph_tree_plot_points=filteredpoints
        # for datapoint in self.graph_tree_plot_points:
        #     self.x_axis.add(float(datapoint.GetAdjustedClock())/1000000)
        # x_axsis_plot=numpy.array(list(self.x_axis))

        # if self.filtermenu_items["by_file_menuitem"].IsChecked() or \
        #   self.highlightmenu_items["by_file_menuitem"].IsChecked():
        #   treepoints = self.tree_list.GetVisiblePoints()
        #   if self.filtermenu_items["by_file_menuitem"].IsChecked():
        #     self.filteredpoints = filteredpoints
        #     self.SetFilteredPointsToGrid()
        #   if self.highlightmenu_items["by_file_menuitem"].IsChecked():
        #     self.OnHighlight(event)

        # self.y_axis=numpy.ones((len(x_axsis_plot),1))
        # self.graph_view_axes.scatter(x_axsis_plot,self.y_axis,picker = 5)
        # self.graph_view_axes.autoscale(enable=True,axis='x')
        # self.figure.canvas.draw()

    def OnTreeOpen(self, event):
        rel_filepath = event.filepath[len(self.common_root_path):]. \
          replace(self.path_separator, os.path.sep)
        abs_filepath = self.settings["SourceDir"] + os.path.sep + rel_filepath
        try:
            if not stat.S_ISREG(os.stat(abs_filepath).st_mode):
                return
        except OSError, e:
            if e.errno == errno.ENOENT:
                self.statusbar.SetStatusText(
                    "Unable to open file for edit. Check Settings")
                return
            else:
                raise
        edit_command = self.settings["EditorCmd"]. \
          replace("$n", str(event.linenum)).replace("$f", abs_filepath)
        if not edit_command:
            return
        if sys.platform == "darwin" or sys.platform == "linux2":
            edit_command += " &"
        os.system(edit_command)

    def OnGridKeyUp(self, event):
        if event.GetKeyCode() == wx.WXK_SHIFT:
            self.grid_shifted = False

    def OnGridKey(self, event):
        if event.GetKeyCode() == wx.WXK_SHIFT:
            self.grid_shifted = True
            return
        if event.GetKeyCode() == wx.WXK_UP:
            self.table_grid.MoveCursorUp(False)
        if event.GetKeyCode() == wx.WXK_DOWN:
            self.table_grid.MoveCursorDown(False)
        if event.GetKeyCode() == wx.WXK_PAGEUP:
            self.table_grid.MovePageUp()
        if event.GetKeyCode() == wx.WXK_PAGEDOWN:
            self.table_grid.MovePageDown()

        self.grid_selected_row = self.table_grid.GetGridCursorRow()
        self.table_grid.SelectRow(self.grid_selected_row)

    def OnPropertyWindowCloseBtn(self,event):
         self.grid_property_splitter.Unsplit(toRemove=self.property_window_panel)
         self.filemenu_items["property_window_menuitem"].Check(False)

    def UpdatePropertyWindowGrid(self,event):
        #Method Updates the property grid upon selection of a datapoint from a grid
        selected_row=event.GetRow()
        datapoint=self.filteredpoints[selected_row]
        item_properties_pane = self.property_window.GetChildren()[1]
        sample_properties_pane = self.property_window.GetChildren()[2]
        if sys.platform=="win32":
            general_pane = item_properties_pane.GetChildren()[2].GetChildren()[0]
            statistics_pane = item_properties_pane.GetChildren()[2].GetChildren()[1]
            appearance_pane = item_properties_pane.GetChildren()[2].GetChildren()[2]
            arguments_pane = sample_properties_pane.GetChildren()[2].GetChildren()[1]
            general_pane_grid = general_pane.GetChildren()[2].GetChildren()[0]
            statistics_pane_grid = statistics_pane.GetChildren()[2].GetChildren()[0]
            appearance_pane_grid = appearance_pane.GetChildren()[2].GetChildren()[0]
            sample_properties_pane_grid = sample_properties_pane.GetChildren()[2].GetChildren()[0]
            arguments_pane_grid = arguments_pane.GetChildren()[2].GetChildren()[0]
        elif sys.platform == "darwin":
            general_pane = item_properties_pane.GetChildren()[1].GetChildren()[0]
            statistics_pane = item_properties_pane.GetChildren()[1].GetChildren()[1]
            appearance_pane = item_properties_pane.GetChildren()[1].GetChildren()[2]
            arguments_pane = sample_properties_pane.GetChildren()[1].GetChildren()[1]
            general_pane_grid = general_pane.GetChildren()[1].GetChildren()[0]
            statistics_pane_grid = statistics_pane.GetChildren()[1].GetChildren()[0]
            appearance_pane_grid = appearance_pane.GetChildren()[1].GetChildren()[0]
            sample_properties_pane_grid = sample_properties_pane.GetChildren()[1].GetChildren()[0]
            arguments_pane_grid = arguments_pane.GetChildren()[1].GetChildren()[0]
        line_number = datapoint.GetLineNumber()
        description = datapoint.GetDescription()
        filename = datapoint.GetFileName()
        function = datapoint.GetFunction()
        clock=float(datapoint.GetAdjustedClock())/1000000
        thread=datapoint.GetThread()
        session_id=datapoint.GetSessionID()
        arguments_list=datapoint.GetArguments()

        general_pane_field_values=[description,"..",filename,function,str(line_number)]
        sample_pane_field_values=["..","..",str(thread),str(clock),str(session_id),"..",description]
        for pane_field_index in range(len(general_pane_field_values)):
            general_pane_grid.SetCellValue(pane_field_index,1,general_pane_field_values[pane_field_index])
        for pane_field_index in range(len(sample_pane_field_values)):
            sample_properties_pane_grid.SetCellValue(pane_field_index,1,sample_pane_field_values[pane_field_index])
        if arguments_pane_grid.GetNumberRows():
            arguments_pane_grid.DeleteRows(0,arguments_pane_grid.GetNumberRows())
        arguments_pane_grid.AppendRows(numRows=len(arguments_list))
        for argument_index in range(len(arguments_list)):
            arguments_pane_grid.SetCellValue(argument_index,0,"arg["+str(argument_index)+"]")
            arguments_pane_grid.SetCellValue(argument_index,1,str(arguments_list[argument_index]))
        sample_properties_pane.GetParent().Layout()

    def UpdatePropertyWindowTreeList(self,FileTreeItem):
        function=FileTreeItem.GetFunctionName()
        linenumber=FileTreeItem.GetLineNumber()
        calls=FileTreeItem.GetNCalls()

    def OnGridSelect(self, event):
        #grid should not be clickable when no files are loaded
        if self.table_grid.GetNumberRows()==0:
            return
        self.UpdatePropertyWindowGrid(event)
        if self.grid_shifted:
            self.table_grid.SetCopyRange(self.grid_selected_row, event.GetRow())
            return
        self.table_grid.ClearCopyRange()
        selected_row = event.GetRow()
        self.grid_selected_row = selected_row
        self.selected_sample_number = \
                int(self.table_grid.GetRowLabelValue(selected_row))
        self.table_grid.SelectRow(selected_row)
        self.table_grid.SetGridCursor(selected_row, 0)
        if event.GetEventType() == wx.grid.wxEVT_GRID_CELL_LEFT_DCLICK:
            self.tree_list.FindPointAndSelect(self.filteredpoints[selected_row].\
                                              GetPointID())
        self.ShowOrHideSearchButtons(selected_row)
        self.grid_text.SetValue(self.table_grid.GetCellValue(selected_row,
                                                             INST_POINT_TABLE_DESC_COL))
        
    def ShowOrHideSearchButtons(self, selected_row):
        if selected_row == 0:
            self.search_button_up.Disable()
            self.search_button_down.Enable()
            self.find_panel_up.Disable()
            self.find_panel_down.Enable()
        elif selected_row == len(self.filteredpoints) - 1:
            self.search_button_up.Enable()
            self.search_button_down.Disable()
            self.find_panel_up.Enable()
            # self.find_panel_down.Disable()
        else:
            self.search_button_up.Enable()
            self.search_button_down.Enable()
            self.find_panel_up.Enable()
            self.find_panel_down.Enable()

    def ShowFilterButtons(self):
        self.filter_low_freq.Enable()
        self.filter_high_freq.Enable()
        self.filter_static.Enable()
        self.context_caption.Enable()

    def OnGridColumnResize(self, event):
        self.column_sizes = self.table_grid.GetColSizes()

    def AddFileMenu(self, menudict):
        filemenu = wx.Menu()
        ColorSelector = wx.Menu()
        menudict["low_color"] = ColorSelector.Append(wx.NewId(), "Low")
        menudict["high_color"] = ColorSelector.Append(wx.NewId(), "High")
        menudict["static_color"] = ColorSelector.Append(wx.NewId(), "Static")
        menudict["about_menuitem"] = filemenu.Append(wx.NewId(), "&About",
                                                "Information about this program")
        menudict["open_menuitem"] = filemenu.Append(wx.NewId(), "&Open",
                                                "Open a file to browse")
        menudict["settings_menuitem"] = filemenu.Append(wx.NewId(), "&Settings",
                                                "Set options for this program")
        menudict["property_window_menuitem"]=filemenu.Append(wx.NewId(),"Property Window","To display the property_window",
                                                    kind=wx.ITEM_CHECK)
        menudict["save_tree_view"]=filemenu.Append(wx.NewId(),"Save Tree View")
        menudict["load_tree_view"]=filemenu.Append(wx.NewId(),"Load Tree View")
        menudict["font_selector_menutitme"]=filemenu.Append(wx.NewId(),"Font Selector","Restart app to apply changes")
        menudict["text_color_selector"]=filemenu.AppendMenu(wx.NewId(), "Text Color Selector", ColorSelector)
        menudict["sort_menuitem"] = filemenu.Append(wx.NewId(), "Case Sensitive/Insensitive Sort ",
                                                "Toggle case-sensitive sort for file tree")
        menudict["tree_view_labels"] = filemenu.Append(wx.NewId(), "Change Tree View Labels",
                                                "Toggle the label of FileTreeItems")
        menudict["background_color"] = filemenu.Append(wx.NewId(), "Set Background Color",
                                                "Set the background color of the datapoint grid")
        menudict["save_blackbox"] = filemenu.Append(wx.NewId(), "Save Blackbox",
                                                "Save Current Points As Separate Blackbox")
        filemenu.AppendSeparator()
        menudict["exit_menuitem"] = filemenu.Append(wx.ID_EXIT, "E&xit",
                                                "Exit the program")
        return filemenu

    def AddFilterHighlightMenu(self, menudict):
        menu = wx.Menu()
        menudict["by_file_menuitem"] = menu.Append(
            wx.NewId(), "By &File",
            "Filter by files open in tree view", kind=wx.ITEM_CHECK)
        menudict["blacklist"] = menu.Append(
            wx.NewId(), "Black List",
            "Black List Points", kind=wx.ITEM_CHECK)
        menudict["by_sel_thread"] = menu.Append(
            wx.NewId(), "By &Thread",
            "Filter by thread of selected item", kind=wx.ITEM_CHECK)
        menudict["by_first_menuitem"] = menu.Append(
            wx.NewId(), "By F&irst",
            "Filter by first item from all threads", kind=wx.ITEM_CHECK)
        menudict["by_last_menuitem"] = menu.Append(
            wx.NewId(), "By &Last",
            "Filter by last item from all threads", kind=wx.ITEM_CHECK)
        menudict["by_low_freq"] = menu.Append(
            wx.NewId(), "By &Low Freq",
            "Filter by low frequencies", kind=wx.ITEM_CHECK)
        menudict["by_high_freq"] = menu.Append(
            wx.NewId(), "By &High Freq",
            "Filter by high frequencies", kind=wx.ITEM_CHECK)
        menudict["by_static_freq"] = menu.Append(
            wx.NewId(), "By &Static Freq",
            "Filter by low or static frequencies", kind=wx.ITEM_CHECK)
        menudict["by_search_expr"] = menu.Append(
            wx.NewId(), "By &Search",
            "Filter by Search expression", kind=wx.ITEM_CHECK)
        menudict["by_a0"] = menu.Append(
            wx.NewId(), "By a&0",
            "Filter by value of a0", kind=wx.ITEM_CHECK)
        menudict["by_a1"] = menu.Append(
            wx.NewId(), "By a&1",
            "Filter by value of a1", kind=wx.ITEM_CHECK)
        menudict["by_args"] = menu.Append(
            wx.NewId(), "By &Args",
            "Filter by Args expression", kind=wx.ITEM_CHECK)
        menudict["reset_clock_filters"] = menu.Append(
            wx.NewId(), "Reset CLock Filters",
            "Reset Clock Filters")
        menu.AppendSeparator()
        menudict["clear_all_filter"] = menu.Append(
            wx.NewId(), "&Clear All", "Clear all filter selections")

        return menu

    def AddMenuBar(self):
        self.filemenu_items = { }
        self.filemenu = self.AddFileMenu(self.filemenu_items)
        self.filemenu.Enable(self.filemenu_items["save_tree_view"].GetId(),False)
        self.filemenu.Enable(self.filemenu_items["load_tree_view"].GetId(),False)
        self.filtermenu_items = { }
        self.filtermenu = self.AddFilterHighlightMenu(self.filtermenu_items)
        self.highlightmenu_items = { }
        self.highlightmenu = self.AddFilterHighlightMenu(self.highlightmenu_items)

        self.Bind(wx.EVT_MENU, self.OnMenuItem)
        menubar = wx.MenuBar()
        menubar.Append(self.filemenu, "&File")
        menubar.Append(self.filtermenu, "F&ilter")
        menubar.Append(self.highlightmenu, "Hi&ghlight")
        self.SetMenuBar(menubar)
        self.DisableFilterHighlightMenus()

    def OnFontSelector(self,event):
        font_dialog=wx.FontDialog(self,wx.FontData())
        if font_dialog.ShowModal() == wx.ID_OK:
                data = font_dialog.GetFontData()
                font = data.GetChosenFont()
                colour = data.GetColour()
                self.font_face=font.GetFaceName()
                self.font_point_size=font.GetPointSize()
        font_dialog.Destroy()

    def OnBackgroundColor(self, event):
        selector = wx.ColourDialog(self)
        selector.ShowModal()
        self.background_color = str(selector.GetColourData().GetColour())
        self.SetFilteredPointsToGrid()

    def OnLowColor(self, event):
        pointdefs = self.parser.GetPointDefinitionVector()
        low = wx.ColourDialog(self)
        low.ShowModal()
        self.low_color = str(low.GetColourData().GetColour())
        self.SetFilteredPointsToGrid()
        pointdefs = self.parser.GetPointDefinitionVector()
        self.treelistdata,self.common_root_path,self.path_separator,self.unrec_tokens = \
          GetTreeListFromPointDefs(pointdefs, self.low_color, self.high_color, self.static_color)
        new_dict = collections.OrderedDict(sorted(self.treelistdata.items(), key=lambda x: x[0].lower()))
        self.treelistdata = new_dict
        self.tree_list.SetTreeList(self.treelistdata, self.sort_case)

    def OnHighColor(self, event):
        high = wx.ColourDialog(self)
        high.ShowModal()
        self.high_color = str(high.GetColourData().GetColour())
        self.SetFilteredPointsToGrid()
        pointdefs = self.parser.GetPointDefinitionVector()
        self.treelistdata,self.common_root_path,self.path_separator,self.unrec_tokens = \
          GetTreeListFromPointDefs(pointdefs, self.low_color, self.high_color, self.static_color)
        new_dict = collections.OrderedDict(sorted(self.treelistdata.items(), key=lambda x: x[0].lower()))
        self.treelistdata = new_dict
        self.tree_list.SetTreeList(self.treelistdata, self.sort_case)

    def OnStaticColor(self, event):
        static = wx.ColourDialog(self)
        static.ShowModal()
        self.static_color = str(static.GetColourData().GetColour())
        self.SetFilteredPointsToGrid()
        pointdefs = self.parser.GetPointDefinitionVector()
        self.treelistdata,self.common_root_path,self.path_separator,self.unrec_tokens = \
          GetTreeListFromPointDefs(pointdefs, self.low_color, self.high_color, self.static_color)
        new_dict = collections.OrderedDict(sorted(self.treelistdata.items(), key=lambda x: x[0].lower()))
        self.treelistdata = new_dict
        self.tree_list.SetTreeList(self.treelistdata, self.sort_case)

    def OnPropertyWindow(self,event):
        if self.filemenu_items["property_window_menuitem"].IsChecked(): #show the property window
            self.grid_property_splitter.SplitVertically(self.table_tree_splitter,self.property_window_panel,-400)# negtative value specifies the size of the left pane
        else :
            self.grid_property_splitter.Unsplit(toRemove=self.property_window_panel)

    def OnSettings(self, event):
        settings = SettingsDialog(self, self.settings)
        result = settings.ShowModal()
        if result == wx.ID_OK:
            self.settings["SourceDir"] = settings.GetSourceDir()
            self.settings["EditorCmd"] = settings.GetEditorCmd()
            if self.settings["SearchModePlainText"] != settings.GetSearchModePlainText():
                self.ShowOrHideSearchButtons(self.grid_selected_row)
            self.settings["SearchModePlainText"] = settings.GetSearchModePlainText()
        settings.Destroy()
    
    def SetFilteredPointsToGrid(self):
        self.table_data = InstPointTable(self.filteredpoints, self.datapoints, self.context_button.GetValue(),
                                         self.filtered_context, self.mode, self.background_color, self.low_color, self.high_color,
                                         self.static_color, colLabels=self.table_labels)
        self.table_grid.SetTable(self.table_data)
        rowindex = 0
        for point in self.filteredpoints:
            if point.GetSampleNumber() == self.selected_sample_number:
                self.table_grid.MakeCellVisible(rowindex, 0)
                self.table_grid.SelectRow(rowindex)
                self.table_grid.SetGridCursor(rowindex, 0)
                self.ShowOrHideSearchButtons(rowindex)
                break
            rowindex = rowindex + 1
        self.table_grid.SetColSizes(self.column_sizes)
        self.table_grid.ForceRefresh()

    def OnHighlight(self, event):
        self.table_grid.ClearCopyRange()
        row_set = set()
        treepoints = None
        thread_id = None
        first_thread_ids = None
        last_thread_ids = None
        by_low_freq = False
        search_expr = None
        search_expr_pattern = None
        search_mode_plain_text = None
        a0_value = None
        a1_value = None
        args_value = None
        highlight_check=False

        if self.highlightmenu_items["by_file_menuitem"].IsChecked():
            treepoints = self.tree_list.GetVisiblePoints()
            highlight_check=True
        if self.highlightmenu_items["by_sel_thread"].IsChecked() and \
          self.thread_caption.GetValue():
            thread_id = int(self.thread_caption.GetValue(), 16)
            highlight_check=True
        if self.highlightmenu_items["by_first_menuitem"].IsChecked():
            first_thread_ids = list(self.thread_ids)
            highlight_check=True
        if self.highlightmenu_items["by_last_menuitem"].IsChecked():
            last_thread_ids = list(self.thread_ids)
            highlight_check=True
        if self.highlightmenu_items["by_low_freq"].IsChecked():
            by_low_freq = True
            highlight_check=True
        if self.highlightmenu_items["by_search_expr"].IsChecked():
            search_expr = self.search_caption.GetValue()
            search_expr_pattern = re.compile(search_expr)
            search_mode_plain_text = self.settings["SearchModePlainText"]
            highlight_check=True
        if self.highlightmenu_items["by_a0"].IsChecked():
            try:
                a0_value = int(self.a0_caption.GetValue())
            except:
                pass
                try:
                    a0_value = eval('lambda V: ' + self.a0_caption.GetValue())
                except:
                    self.statusbar.SetStatusText(
                        "Value for a0 '" + a0_val + "' is not a base 10 integer or a V expression")
        if self.highlightmenu_items["by_a1"].IsChecked():
            try:
                a1_value = int(self.a1_caption.GetValue())
            except:
                pass
                try:
                    a1_value = eval('lambda V: ' + self.a1_caption.GetValue())
                except:
                    self.statusbar.SetStatusText(
                        "Value for a1 '" + a1_val + "' is not a base 10 integer or a V expression")
            highlight_check=True

        if self.highlightmenu_items["by_args"].IsChecked():
            try:
                args_value = eval('lambda A: ' + self.args_caption.GetValue())
            except:
                self.statusbar.SetStatusText(
                    "Value for arg '" + args_val + "' is not an A[] expression")
            highlight_check=True

        if not highlight_check:
            return;

        self.DisableFilterHighlightMenus()
        self.filter_blacklist.Disable()
        self.filter_static.Disable()
        self.filter_low_freq.Disable()
        self.filter_high_freq.Disable()
        self.filter_tree.Disable()
        self.context_button.Disable()
        self.search_button_down.Disable()
        self.search_button_up.Disable()
        # self.find_panel_down.Disable()
        self.find_panel_up.Disable()
        for row_index in range(0, self.table_data.GetNumberRows()):
            if (row_index % random.randint(200,500)) == 0:
                self.HighlightYield(row_index)
            if treepoints != None:
                if self.HighlightFilteredPointsByFiles(row_index, row_set, treepoints):
                    continue
            if thread_id != None:
                if self.HighlightFilteredPointsByThreadId(row_index, row_set, thread_id):
                    continue
            if first_thread_ids:
                if self.HighlightFilteredPointsByFirstThreadIds(
                        row_index, row_set, first_thread_ids):
                    continue
            if last_thread_ids:
                if self.HighlightFilteredPointsByLastThreadIds(
                        row_index, row_set, last_thread_ids):
                    continue
            if by_low_freq:
                if self.HighlightFilteredPointsByLowFreq(row_index, row_set):
                    continue
            if search_expr != None:
                if self.HighlightFilteredPointsBySearch(
                  row_index, row_set, search_expr, search_expr_pattern,
                  search_mode_plain_text):
                    continue
            if a0_value != None and a1_value == None:
                if self.HighlightFilteredPointsByA0(row_index, row_set, a0_value):
                    continue
            if a1_value != None and a0_value == None:
                if self.HighlightFilteredPointsByA1(row_index, row_set, a1_value):
                    continue
            if a0_value != None and a1_value != None:
                if self.HighlightFilteredPointsByA0AndA1(row_index, row_set,
                                                         a0_value, a1_value):
                    continue
            if args_value != None:
                if self.HighlightFilteredPointsByArgs(row_index, row_set, args_value):
                    continue

        self.EnableFilterHighlightMenus()
        self.filter_blacklist.Enable()
        self.filter_static.Enable()
        self.filter_low_freq.Enable()
        self.filter_high_freq.Enable()
        self.filter_tree.Enable()
        self.context_button.Enable()
        self.search_button_down.Enable()
        self.search_button_up.Enable()
        self.find_panel_up.Enable()
        self.find_panel_down.Enable()
        self.statusbar.SetStatusText("")
        self.table_data.SetRowHighlightSet(row_set)
        self.table_grid.ForceRefresh()

    def OnFilter(self, event):
        self.filteredpoints = self.datapoints
        if self.filtermenu_items["by_file_menuitem"].IsChecked():
            self.filter_tree.SetValue(True)
            treepoints = self.tree_list.GetVisiblePoints()
            self.filteredpoints = self.FilterDataPointsByIds(
                self.datapoints, treepoints)
        else:
            self.filter_tree.SetValue(False)
        if self.filtermenu_items["blacklist"].IsChecked():
            self.filter_blacklist.SetValue(True)
            blacklist_points=self.tree_list.blacklist_points
            self.filteredpoints =self.FilterBlacklist(self.filteredpoints,blacklist_points)
        else:
            self.filter_blacklist.SetValue(False)
        if self.filtermenu_items["by_sel_thread"].IsChecked() and \
          self.thread_caption.GetValue():
            thread_id = int(self.thread_caption.GetValue(), 16)
            self.filteredpoints = self.FilterDataPointsByThread(
                self.filteredpoints, thread_id)
        if self.filtermenu_items["by_first_menuitem"].IsChecked():
            thread_ids = list(self.thread_ids)
            self.filteredpoints = self.FilterDataPointsByFirst(
                self.filteredpoints, thread_ids)
        if self.filtermenu_items["by_last_menuitem"].IsChecked():
            thread_ids = list(self.thread_ids)
            self.filteredpoints = self.FilterDataPointsByLast(
                self.filteredpoints, thread_ids)
        if self.filtermenu_items["by_low_freq"].IsChecked():
            self.filter_low_freq.SetValue(True)
            self.filteredpoints = self.FilterDataPointsByLowFreq(
                self.filteredpoints)
        else:
            self.filter_low_freq.SetValue(False)
        if self.filtermenu_items["by_high_freq"].IsChecked():
            self.filter_high_freq.SetValue(True)
            self.filteredpoints = self.FilterDataPointsByHighFreq(
                self.filteredpoints)
        else:
            self.filter_high_freq.SetValue(False)
        if self.filtermenu_items["by_static_freq"].IsChecked():
            self.filter_static.SetValue(True)
            self.filteredpoints = self.FilterDataPointsByStaticFreq(
                self.filteredpoints)
        else:
            self.filter_static.SetValue(False)
        if self.filtermenu_items["by_search_expr"].IsChecked():
            self.filteredpoints = self.FilterDataPointsBySearch(
                self.filteredpoints, self.search_caption.GetValue())
        if self.filtermenu_items["by_a0"].IsChecked():
            self.filteredpoints = self.FilterDataPointsByA0(
                self.filteredpoints, self.a0_caption.GetValue())
        if self.filtermenu_items["by_a1"].IsChecked():
            self.filteredpoints = self.FilterDataPointsByA1(
                self.filteredpoints, self.a1_caption.GetValue())
        if self.filtermenu_items["by_args"].IsChecked():
            self.filteredpoints = self.FilterDataPointsByArgs(
                self.filteredpoints, self.args_caption.GetValue())
        if self.context_button.GetValue():
            self.filteredpoints = self.FilterWithContext(self.context_value, self.filteredpoints,
                                    self.datapoints)
        disable_clock = False
        if self.filtermenu_items["reset_clock_filters"].GetId()==event.GetId():
            self.before_clock_caption.SetValue("")
            self.after_clock_caption.SetValue("")
            disable_clock=True
        self.EnableDisableContextButton()
        self.SetFilteredPointsToGrid()
        self.OnHighlight(event)
        #reset clock filter is disabled here as OnHighlight enables the complete filtermenu
        if disable_clock:
            self.filtermenu.Enable(self.filtermenu_items["reset_clock_filters"].GetId(),False)

    def FilterWithContext(self, value, filtered_points, data_points):
        filtered = list(filtered_points)
        self.filtered_context = filtered
        new_dict = {}
        indices = [x.GetUniqueID() for x in filtered]
        for sample in indices:
            ran_ge = value
            while ran_ge >= -value:
                if sample - ran_ge >= 0 and sample - ran_ge < len(self.datapoints):
                    new_dict[self.datapoints[sample-ran_ge].GetUniqueID()] = self.datapoints[sample-ran_ge]
                ran_ge -= 1
        return sorted(new_dict.values(), key = lambda x: x.GetUniqueID())

    def FilterWithContext(self, value, filtered_points, data_points):
        filtered = list(filtered_points)
        self.filtered_context = filtered
        new_dict = {}
        indices = [x.GetUniqueID() for x in filtered]
        for sample in indices:
            ran_ge = value
            while ran_ge >= -value:
                if sample - ran_ge >= 0 and sample - ran_ge < len(self.datapoints):
                    new_dict[self.datapoints[sample-ran_ge].GetUniqueID()] = self.datapoints[sample-ran_ge]
                ran_ge -= 1

        return sorted(new_dict.values(), key = lambda x: x.GetUniqueID())


    def FilterDataPointsByA0(self, data_points, a0_val):
        int_val = None
        lambda_val = None
        self.statusbar.SetStatusText('')
        try:
            int_val = int(a0_val)
        except:
            pass
            try:
                lambda_val = eval('lambda V: ' + a0_val)
            except:
                self.statusbar.SetStatusText(
                    "Value for a0 '" + a0_val + "' is not a base 10 integer or a V expression")
                return []
        newpoints = []
        if int_val is not None:
            for item in data_points:
                if item.HasSessionID() and item.GetSessionID() == int_val:
                    newpoints.append(item)
        else:
            try:
                for item in data_points:
                    if item.HasSessionID() and lambda_val(item.GetSessionID()):
                        newpoints.append(item)
            except:
                self.statusbar.SetStatusText("Error evaluating '" + a0_val + "' expression")
                return []
            
        return newpoints
        
    def FilterDataPointsByA1(self, data_points, a1_val):
        int_val = None
        lambda_val = None
        self.statusbar.SetStatusText('')
        try:
            int_val = int(a1_val)
        except:
            pass
            try:
                lambda_val = eval('lambda V: ' + a1_val)
            except:
                self.statusbar.SetStatusText(
                    "Value for a1 '" + a1_val + "' is not a base 10 integer or a V expression")
                return []
        newpoints = []
        if int_val is not None:
            for item in data_points:
                if item.HasSocketID() and item.GetSocketID() == int_val:
                    newpoints.append(item)
        else:
            try:
                for item in data_points:
                    if item.HasSocketID() and lambda_val(item.GetSocketID()):
                        newpoints.append(item)
            except:
                self.statusbar.SetStatusText("Error evaluating '" + a1_val + "' expression")
                return []
        return newpoints

    def FilterDataPointsByArgs(self, data_points, args_val):
        lambda_val = None
        self.statusbar.SetStatusText('')
        try:
            lambda_val = eval('lambda A,D: ' + args_val)
        except:
            self.statusbar.SetStatusText(
                "Value for Args '" + args_val + "' is not an A[] expression")
            return []
        newpoints = []
        try:
            for item in data_points:
                if lambda_val(item.GetArguments(), item.GetFormatString()):
                    newpoints.append(item)
        except:
            self.statusbar.SetStatusText("Error evaluating '" + args_val + "' expression")
            return []
        return newpoints

    def HighlightFilteredPointsByFiles(self, row_index, row_set, ids):
        if self.table_data.GetRowDataId(row_index) in ids:
          row_set.add(row_index)
          return True
        return False

    def HighlightFilteredPointsByThreadId(self, row_index, row_set, thread_id):
        if self.table_data.GetRowThreadId(row_index) == thread_id:
          row_set.add(row_index)
          return True
        return False

    def HighlightFilteredPointsByFirstThreadIds(self, row_index, row_set,
                                                first_thread_ids):
        thread_id = self.table_data.GetRowThreadId(row_index)
        if thread_id in first_thread_ids:
            row_set.add(row_index)
            first_thread_ids.remove(thread_id)
            return True
        return False

    def HighlightFilteredPointsByLastThreadIds(self, row_index, row_set,
                                                last_thread_ids):
        reverse_row_index = self.table_data.GetNumberRows() - row_index - 1
        thread_id = self.table_data.GetRowThreadId(reverse_row_index)
        if reverse_row_index not in row_set and thread_id in last_thread_ids:
            row_set.add(reverse_row_index)
            last_thread_ids.remove(thread_id)
        return True

    def HighlightFilteredPointsByLowFreq(self, row_index, row_set):
        if self.table_data.GetTypeForRow(row_index) == \
          InstrumentationModel.PointDefinition.type_low:
            row_set.add(row_index)
            return True
        return False

    def HighlightFilteredPointsBySearch(self, row_index, row_set,
                                        search_expr, search_expr_pattern,
                                        search_mode_plain_text):
        description = self.table_data.GetDescriptionForRow(row_index)
        if search_mode_plain_text:
            if search_expr in description:
                row_set.add(row_index)
                return True
            else:
                if search_expr_pattern.match(description):
                    row_set.add(row_index)
                    return True
        return False

    def HighlightFilteredPointsByA0(self, row_index, row_set, a0_value):
        session_value = self.table_data.GetSessionIdForRow(row_index)
        if session_value != None:
            if isinstance(a0_value, types.LambdaType):
                if a0_value(session_value):
                    row_set.add(row_index)
                    return True
            else:
                if a0_value == session_value:
                    row_set.add(row_index)
                    return True
        return False

    def HighlightFilteredPointsByA1(self, row_index, row_set, a1_value):
        socket_value = self.table_data.GetSocketIdForRow(row_index)
        if socket_value != None:
            if isinstance(a1_value, types.LambdaType):
                if a1_value(socket_value):
                    row_set.add(row_index)
                    return True
            else:
                if a1_value == socket_value:
                    row_set.add(row_index)
                    return True
        return False

    def HighlightFilteredPointsByA0AndA1(self, row_index, row_set, a0_value, a1_value):
        session_value = self.table_data.GetSessionIdForRow(row_index)
        socket_value = self.table_data.GetSocketIdForRow(row_index)
        if session_value != None and socket_value != None:
            if isinstance(a0_value, types.LambdaType):
                if a0_value(session_value):
                    if isinstance(a1_value, types.LambdaType):
                        if a1_value(socket_value):
                            row_set.add(row_index)
                            return True
                    else:
                        if a1_value == socket_value:
                            row_set.add(row_index)
                            return True
            else:
                if a0_value == session_value:
                    if isinstance(a1_value, types.LambdaType):
                        if a1_value(socket_value):
                            row_set.add(row_index)
                            return True
                    else:
                        if a1_value == socket_value:
                            row_set.add(row_index)
                            return True
        return False

    def HighlightFilteredPointsByArgs(self, row_index, row_set, args_value):
        args = self.table_data.GetRowArguments(row_index)
        try:
            if args_value(args):
                row_set.add(row_index)
                return True
        except:
            pass

        return False

    def FilterBlacklist(self,data_points,blacklist_points):
        new_points = [item for item in data_points if item.GetPointID() not in blacklist_points]
        return new_points

    def FilterDataPointsByIds(self, data_points, ids):
        newpoints=[]
        list_interface=InstrumentationModel.ThreadIdSet()
        for id in ids:
            list_interface.add(id)
        newpoints=self.parser.FilterByFile(data_points,list_interface)
        return newpoints

    def FilterDataPointsByThread(self, data_points, thread_id):
        newpoints = []
        for item in data_points:
            if item.GetThread() == thread_id:
                newpoints.append(item)
        return newpoints

    def FilterDataPointsByFirst(self, data_points, thread_ids):
        newpoints = []
        for item in data_points:
            if item.GetThread() in thread_ids:
                newpoints.append(item)
                thread_ids.remove(item.GetThread())
        return newpoints

    def FilterDataPointsByLast(self, data_points, thread_ids):
        newpoints = []
        for item in reversed(data_points):
            if item.GetThread() in thread_ids:
                newpoints.insert(0, item)
                thread_ids.remove(item.GetThread())
        return newpoints

    def FilterDataPointsByLowFreq(self, data_points):
        newpoints = []
        data_points_vector=InstrumentationModel.DataPointVector()
        for data_point in data_points:
            data_points_vector.push_back(data_point)
        newpoints=self.parser.FilterByFreq(data_points_vector,"low")
        return newpoints

    def FilterDataPointsByHighFreq(self, data_points):
        newpoints = []
        data_points_vector=InstrumentationModel.DataPointVector()
        for data_point in data_points:
            data_points_vector.push_back(data_point)
        newpoints=self.parser.FilterByFreq(data_points_vector,"high")
        return newpoints

    def FilterDataPointsByStaticFreq(self, data_points):
        newpoints = []
        data_points_vector=InstrumentationModel.DataPointVector()
        for data_point in data_points:
            data_points_vector.push_back(data_point)
        newpoints=self.parser.FilterByFreq(data_points_vector,"static")
        return newpoints

    def DisableFilterHighlightMenus(self):
        for name,menu in self.filtermenu_items.iteritems():
            self.filtermenu.Enable(menu.GetId(), enable=False)
        for name,menu in self.highlightmenu_items.iteritems():
            self.highlightmenu.Enable(menu.GetId(), enable=False)

    def EnableFilterHighlightMenus(self):
        for name,menu in self.filtermenu_items.iteritems():
            self.filtermenu.Enable(menu.GetId(), enable=True)
            if not self.loaded_desc_list:
                self.filtermenu.Enable(self.filtermenu_items["by_search_expr"].GetId(),False)
        for name,menu in self.highlightmenu_items.iteritems():
            self.highlightmenu.Enable(menu.GetId(), enable=True)

    def EnableDisableContextButton(self):
        if len(self.filteredpoints) == len(self.datapoints):
            self.context_button.Disable()
        else:
            self.context_button.Enable()

    def HighlightYield(self, row):
        self.statusbar.SetStatusText("Highlighting row "+str(row))
        wx.Yield()

    def FilterYield(self, row):
        self.statusbar.SetStatusText("Checking row "+str(row))
        wx.Yield()

    def FilterDataPointsBySearch(self, data_points, search_expr):
        newpoints = []
        search_mode_plain_text = self.settings["SearchModePlainText"]
        data_points_set=InstrumentationModel.ThreadIdSet()
        start=time.time()
        for data_point in data_points:
            data_points_set.append(data_point.GetUniqueID())
        end=time.time()
        self.DisableFilterHighlightMenus()
        self.statusbar.SetStatusText("Searching for Matches")
        newpoints=self.parser.FilterSearch(data_points_set,str(search_expr),search_mode_plain_text)
        self.EnableFilterHighlightMenus()
        self.statusbar.SetStatusText("")
        return newpoints

    def SortFileTree(self):
        expanded_points=self.tree_list.GetExpandedNodes()
        if self.sort_case:
            self.tree_list.SetTreeList(self.treelistdata, self.sort_case)
            expanded_points=sorted(expanded_points)
        else:
            new_dict = collections.OrderedDict(sorted(self.treelistdata.items(), key=lambda x: x[0].lower()))
            self.treelistdata = new_dict
            self.tree_list.SetTreeList(self.treelistdata, self.sort_case)
            expanded_points=sorted(expanded_points, key=lambda s: s.lower())
        self.tree_list.SetTreeStructure(expanded_points)

    def OnMenuItem(self, event):
        event_id = event.GetId()
        if event_id in [ m.GetId() for m in self.filemenu_items.values() ]:
            if event_id == self.filemenu_items["about_menuitem"].GetId():
                self.OnAbout(event)
            if event_id == self.filemenu_items["open_menuitem"].GetId():
                self.OnOpen(event)
            if event_id == self.filemenu_items["settings_menuitem"].GetId():
                self.OnSettings(event)
            if event_id == self.filemenu_items["property_window_menuitem"].GetId():
                self.OnPropertyWindow(event)
            if event_id == self.filemenu_items["save_tree_view"].GetId():
                self.OnSaveTreeView(event)
            if event_id == self.filemenu_items["load_tree_view"].GetId():
                self.OnLoadTreeView(event)
            if event_id == self.filemenu_items["font_selector_menutitme"].GetId():
                self.OnFontSelector(event)
            if event_id == self.filemenu_items["low_color"].GetId():
                self.OnLowColor(event)
            if event_id == self.filemenu_items["high_color"].GetId():
                self.OnHighColor(event)
            if event_id == self.filemenu_items["static_color"].GetId():
                self.OnStaticColor(event)
            if event_id == self.filemenu_items["exit_menuitem"].GetId():
                self.OnExit(event)
            if event_id == self.filemenu_items["sort_menuitem"].GetId():
                self.OnSort(event)
            if event_id == self.filemenu_items["tree_view_labels"].GetId():
                self.OnChangeTreeView(event)
            if event_id == self.filemenu_items["background_color"].GetId():
                self.OnBackgroundColor(event)
            if event_id == self.filemenu_items["save_blackbox"].GetId():
                self.OnSaveBlackBox(event)
            return

        if event_id == self.search_key_id:
            self.find_panel.Show(True)
            self.find_panel_search_box.SetFocus()
            self.right_panel.Layout()
            return
        
        if event_id in [ m.GetId() for m in self.filtermenu_items.values() ]:
            menu = self.filtermenu_items
        elif event_id in [ m.GetId() for m in self.highlightmenu_items.values() ]:
            menu = self.highlightmenu_items
        if event_id == menu["clear_all_filter"].GetId():
            menu["by_file_menuitem"].Check(False)
            menu["by_sel_thread"].Check(False)
            menu["by_first_menuitem"].Check(False)
            menu["by_last_menuitem"].Check(False)
            menu["by_low_freq"].Check(False)
            menu["by_search_expr"].Check(False)
        if event_id == menu["by_first_menuitem"].GetId() and \
          menu["by_first_menuitem"].IsChecked():
            menu["by_last_menuitem"].Check(False)
        if event_id == menu["by_last_menuitem"].GetId() and \
          menu["by_last_menuitem"].IsChecked():
            menu["by_first_menuitem"].Check(False)

        if menu is self.filtermenu_items:
            self.OnFilter(event)
        if menu is self.highlightmenu_items:
            self.OnHighlight(event)

    def OnChangeTreeView(self, event):
        self.tree_view_labels = not self.tree_view_labels
        self.tree_list.SetTreeList(self.treelistdata, self.sort_case)

    def OnSort(self, event):
        self.sort_case = not self.sort_case
        self.SortFileTree()
        
    def OnAbout(self, event):
        if self.unrec_tokens:
            unrec_message = "Unrecognized tokens in loaded data:\n"
        else:
            unrec_message = ""
        for unrec_token in self.unrec_tokens:
            unrec_message += unrec_token.GetAsString() + "\n"
        dlg = wx.MessageDialog(self, "A browser for instrumentation data\n\n" +
                               "Version " +
                               InstrumentationBrowserVersion.git_description + "\n\n" +
                               unrec_message,
                               "About the Instrumentation Browser",
                               wx.OK)
        dlg.ShowModal()
        dlg.Destroy()

    def OnStart(self):
        configpath = os.path.join(expanduser("~"),
                                  ".InstrumentationBrowser.ini")
        try:
            configfile = open(configpath, "r")
            config_string = configfile.read()
            configfile.close()
            configitems = json.loads(config_string)
        except IOError, e:
            if e.errno == errno.ENOENT:
                pass
        try:
            for search_item in configitems["SearchItems"]:
                self.search_caption.Append(search_item)
            for search_item in configitems["A0Items"]:
                self.a0_caption.Append(search_item)
            for search_item in configitems["A1Items"]:
                self.a1_caption.Append(search_item)
            for search_item in configitems["ArgsItems"]:
                self.args_caption.Append(search_item)
            if "WindowPos" in configitems:
                new_position = configitems["WindowPos"]
                if wx.Display.GetFromPoint(new_position) != wx.NOT_FOUND:
                    self.SetPosition(new_position)
            if "WindowSize" in configitems: self.window_size = configitems["WindowSize"]
            # if "ColSize" in configitems: self.column_sizes = configitems["ColSize"]
            if "SourceDir" in configitems:
                self.settings["SourceDir"] = configitems["SourceDir"]
            if "EditorCmd" in configitems:
                self.settings["EditorCmd"] = configitems["EditorCmd"]
            if "SearchModePlainText" in configitems:
                self.settings["SearchModePlainText"] = configitems["SearchModePlainText"]
            if "SplitPos" in configitems:
                self.table_tree_splitter.SetSashPosition(configitems["SplitPos"])
            if "FileTreeSort" in configitems:
                self.sort_case = configitems["FileTreeSort"]
            if "TreeViewLabels" in configitems:
                self.tree_view_labels = configitems["TreeViewLabels"] 
            if "BackgroundColor" in configitems:
                self.background_color = configitems["BackgroundColor"]
            if "LowFreqTextColor" in configitems:
                self.low_color = configitems["LowFreqTextColor"]
            if "HighFreqTextColor" in configitems:
                self.high_color = configitems["HighFreqTextColor"]
            if "StaticTextColor" in configitems:
                self.static_color = configitems["StaticTextColor"]

        except:
            pass
        self.SetSize(self.window_size)
        self.SetFilteredPointsToGrid()

    def OnExit(self, event):
        self.Close(True)

    def OnClose(self, event):
        search_items = []
        for item_index in range(self.search_caption.GetCount()):
            item = self.search_caption.GetString(item_index)
            if item:
                search_items.append(item)
        a0_items = []
        for item_index in range(self.a0_caption.GetCount()):
            item = self.a0_caption.GetString(item_index)
            if item:
                a0_items.append(item)
        a1_items = []
        for item_index in range(self.a1_caption.GetCount()):
            item = self.a1_caption.GetString(item_index)
            if item:
                a1_items.append(item)
        args_items = []
        for item_index in range(self.args_caption.GetCount()):
            item = self.args_caption.GetString(item_index)
            if item:
                args_items.append(item)
        configitems = { "SearchItems": search_items,
                        "A0Items": a0_items,
                        "A1Items": a1_items,
                        "ArgsItems": args_items,
                        "WindowPos": self.GetPosition().Get(),
                        "WindowSize": self.GetSize().Get(),
                        "ColSize": self.column_sizes,
                        "SplitPos": self.table_tree_splitter.GetSashPosition(),
                        "SourceDir": self.settings["SourceDir"],
                        "EditorCmd": self.settings["EditorCmd"],
                        "SearchModePlainText": self.settings["SearchModePlainText"],
                        "Font Attributes":{"font_face":self.font_face,"font_point_size":self.font_point_size},
                        "FileTreeSort": self.sort_case,
                        "TreeViewLabels" : self.tree_view_labels,
                        "BackgroundColor" : self.background_color,
                        "LowFreqTextColor": self.low_color,
                        "HighFreqTextColor": self.high_color,
                        "StaticTextColor": self.static_color }

        config_string = json.dumps(configitems, sort_keys=True, indent=4,
                                   separators=(',', ': '))
        configpath = os.path.join(expanduser("~"),
                                  ".InstrumentationBrowser.ini")
        configfile = open(configpath, "w")
        configfile.write(config_string)
        configfile.close()
        self.Destroy()

    def OnOpen(self, event):
        """ Open a file"""
        dlg = wx.FileDialog(self, "Choose a file", self.dirname, \
                            "", "Dat file or tarball (*.gz; *.dat, *.tar)|*.gz;*.dat;*.tar", wx.OPEN)
        if dlg.ShowModal() == wx.ID_OK:
            filename = dlg.GetPath()
            if filename.endswith('.tar.gz'):
                tar = tarfile.open(filename, "r:gz")
                for members in tar:
                    if os.path.splitext(members.name)[1] == ".dat":
                        tar.extract(members.name)
                        self.Load(members.name)
                        shutil.rmtree('tmp')
                        break
            if filename.endswith('.tar'):
                tar = tarfile.open(filename, "r:*")
                for members in tar:
                    if os.path.splitext(members.name)[1] == ".dat":
                        tar.extract(members.name)
                        self.Load(members.name)
                        shutil.rmtree('tmp')
                        break
            if filename.endswith('.dat'):
                self.Load(filename)
        dlg.Destroy()

    def OnSaveBlackBox(self,event):
        sample_number=InstrumentationModel.SampleNumberSet()
        for  filteredpoint in self.filteredpoints:
            sample_number.add(filteredpoint.GetSampleNumber())
        save_bb_dlg = wx.FileDialog(self, "Save Blackbox", style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT)
        if save_bb_dlg.ShowModal() == wx.ID_OK:
            filepath = str(save_bb_dlg.GetPath())
            self.parser.CreateDatFile(filepath + ".dat",sample_number)
            save_bb_dlg.Destroy()

    def OnSaveTreeView(self,event):
        """save tree view"""  
        expanded_points=self.tree_list.GetExpandedNodes()
        points_dictionary={}
        points_dictionary["expanded_points"]=expanded_points
        exapnaded_points_string=json.dumps(points_dictionary,separators=(',',': '))
        save_tree_dlg = wx.FileDialog(self, "Save file",style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT)
        if save_tree_dlg.ShowModal() == wx.ID_OK:
            filepath = save_tree_dlg.GetPath()
            save_tree_file = open(filepath+ ".txt", "w")
            save_tree_file.write(exapnaded_points_string)
            save_tree_file.close()
            save_tree_dlg.Destroy()

    def OnLoadTreeView(self,event):
        """load tree view"""
        open_tree_dlg = wx.FileDialog(self, "Choose a file", self.dirname, \
                            "", "*.txt", wx.OPEN)
        if open_tree_dlg.ShowModal() == wx.ID_OK:
            filepath=open_tree_dlg.GetPath()
            try:
                save_tree_file= open(filepath, "r")
                save_file_string = save_tree_file.read()
                save_tree_file.close()
                file_dict = json.loads(save_file_string)
            except IOError, e:
                if e.errno == errno.ENOENT:
                    pass
            if "expanded_points" in file_dict:
                file_names=file_dict['expanded_points']
                if self.sort_case == True :
                    file_names=sorted(file_names)
                else :
                    file_names=sorted(file_names, key=lambda s: s.lower())
                self.tree_list.SetTreeStructure(file_names)
            else:
                return

    def CreateDescriptionList(self):
        self.parser.CreateDescrptionList(self.datapoints)
        self.loaded_desc_list = True
        self.statusbar.SetStatusText("")
        self.filtermenu.Enable(self.filtermenu_items["by_search_expr"].GetId(),True)

    def Load(self, filename):
        fname = str(filename)
        self.parser = InstrumentationModel.InstrumentationModel_Load(fname)
        self.parser.Sort()
        self.datapoints = self.parser.GetDataPoints()
        self.filteredpoints = self.datapoints
        self.selected_sample_number = self.filteredpoints[0].GetSampleNumber()
        self.selected_column_number = 0
        self.SetFilteredPointsToGrid()
        self.parser.ClearDescriptionList()
        pointdefs = self.parser.GetPointDefinitionVector()
        self.treelistdata,self.common_root_path,self.path_separator,self.unrec_tokens = \
          GetTreeListFromPointDefs(pointdefs, self.low_color, self.high_color, self.static_color)
        new_dict = collections.OrderedDict(sorted(self.treelistdata.items(), key=lambda x: x[0].lower()))
        self.treelistdata = new_dict
        self.tree_list.SetTreeList(self.treelistdata, self.sort_case)
        self.thread_ids = self.parser.GetThreadIds()
        self.thread_caption.AppendItems(map(hex, self.thread_ids))
        self.filter_tree.Enable()
        self.filter_static.Enable()
        self.filter_blacklist.Enable()
        self.filter_low_freq.Enable()
        self.filter_high_freq.Enable()
        self.EnableFilterHighlightMenus()
        self.ShowOrHideSearchButtons(0)
        self.filemenu.Enable(self.filemenu_items["save_tree_view"].GetId(),True)
        self.filemenu.Enable(self.filemenu_items["load_tree_view"].GetId(),True)
        self.EnableFilterHighlightMenus()
        self.filtermenu.Enable(self.filtermenu_items["reset_clock_filters"].GetId(),False)
        self.ShowOrHideSearchButtons(0)
        self.ShowFilterButtons()
        self.loaded_desc_list = False
        self.download_thread=threading.Thread(target=self.CreateDescriptionList)
        self.download_thread.daemon=True
        self.download_thread.start()
        self.filtermenu.Enable(self.filtermenu_items["by_search_expr"].GetId(),False)
        self.statusbar.SetStatusText("Please wait before applying search filter")
        
def usage():
    warning("usage: " + sys.argv[0] + " [-h] [input-file]\n\
             -h, --help      - help/usage message\n\
             input-file      - blackbox to browse")

def main(argv=None):
    if argv is None:
        argv = sys.argv
    loadfilepath = None
    font_attributes=""

    try:
        opts, args = getopt.getopt(argv[1:], "h", ["help"])
        for o, a in opts:
            if o in ("-h", "--help"):
                usage()
                return 0
            else:
                assert False, "unhandled option"
        if len(args) == 1:
            loadfilepath = args[0]
            try:
                loadfilehandle = open(loadfilepath, 'r')
                loadfilehandle.close()
            except IOError, e:
                if e.errno == errno.ENOENT:
                    warning("file not found: \"" +
                            loadfilepath + "\"")
                    return 1
                else:
                    raise
        elif len(args) != 0:
            usage()
            return 0
    except getopt.GetoptError as err:
        warning(err)
        usage()
        return 2

    configpath = os.path.join(expanduser("~"),
                                  ".InstrumentationBrowser.ini")
    try:
        configfile = open(configpath, "r")
        config_string = configfile.read()
        configfile.close()
        configitems = json.loads(config_string)
        if "Font Attributes" in configitems:
            font_attributes=configitems["Font Attributes"]

    except IOError, e:
        if e.errno == errno.ENOENT:
             pass

    if not font_attributes:
        font_attributes={"font_face":"wx.DEFAULT","font_point_size":"wx.DEFAULT"}

    app = wx.App(False)
    frame = MainWindow(None, "Instrumentation Browser",font_attributes)
    frame.OnStart()
    if loadfilepath:
        frame.Load(loadfilepath)

    app.MainLoop()
    return 0
    
if __name__ == "__main__":
    sys.exit(main())
#   cProfile.run('main()')
    
